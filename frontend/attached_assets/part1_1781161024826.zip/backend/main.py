"""
AstroGen — FastAPI Backend
Runs on http://localhost:8001
All model inference, DB operations, and Gemini calls go through here.
Frontend (PyQt6) calls these endpoints via requests library.
"""

import os
import sys
import base64
import io
from typing import Optional
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import uvicorn

# Add parent to path
sys.path.insert(0, os.path.dirname(__file__))

from database import (
    create_session, get_all_sessions, rename_session, delete_session,
    add_message, get_session_messages, get_session_context,
    save_generated_image, get_all_generated_images, image_to_base64
)
from models import (
    generate_image_lora, generate_image_gan, caption_image,
    get_model_status, enrich_prompt
)
from gemini import ask_gemini, is_gemini_available

app = FastAPI(title="AstroGen API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve generated images as static files
_generated_dir = os.path.join(os.path.dirname(__file__), '..', 'data', 'generated')
os.makedirs(_generated_dir, exist_ok=True)
app.mount("/generated", StaticFiles(directory=_generated_dir), name="generated")


# ── Pydantic Models ─────────────────────────────────────────────────────────

class GenerateRequest(BaseModel):
    prompt: str
    model: str = "lora_sd"          # "lora_sd" | "vae_gan"
    session_id: Optional[int] = None
    num_steps: int = 30
    guidance_scale: float = 7.5
    seed: Optional[int] = None
    width: int = 512
    height: int = 512

class ChatRequest(BaseModel):
    message: str
    session_id: int
    image_b64: Optional[str] = None  # base64 image for multimodal

class SessionRenameRequest(BaseModel):
    title: str

class CaptionRequest(BaseModel):
    image_b64: str
    question: Optional[str] = None
    session_id: Optional[int] = None


# ── Health / Status ─────────────────────────────────────────────────────────

@app.get("/")
def root():
    return {"status": "AstroGen API running", "version": "1.0.0"}


@app.get("/status")
def status():
    """Returns model availability and system info."""
    model_status = get_model_status()
    return {
        "models": model_status,
        "gemini": is_gemini_available(),
        "db_sessions": len(get_all_sessions()),
    }


# ── Sessions ────────────────────────────────────────────────────────────────

@app.get("/sessions")
def list_sessions():
    return get_all_sessions()


@app.post("/sessions")
def new_session(title: str = "New Chat"):
    session_id = create_session(title)
    return {"session_id": session_id, "title": title}


@app.put("/sessions/{session_id}")
def update_session(session_id: int, body: SessionRenameRequest):
    rename_session(session_id, body.title)
    return {"ok": True}


@app.delete("/sessions/{session_id}")
def remove_session(session_id: int):
    delete_session(session_id)
    return {"ok": True}


@app.get("/sessions/{session_id}/messages")
def session_messages(session_id: int):
    return get_session_messages(session_id)


# ── Image Generation ─────────────────────────────────────────────────────────

@app.post("/generate")
def generate(req: GenerateRequest):
    """
    Generate astronomical image.
    Model choices:
      lora_sd  — LoRA fine-tuned Stable Diffusion (text-to-image)
      vae_gan  — VAE-GAN decoder (random generation)
    """
    try:
        if req.model == "lora_sd":
            img_bytes = generate_image_lora(
                prompt=req.prompt,
                num_steps=req.num_steps,
                guidance_scale=req.guidance_scale,
                width=req.width,
                height=req.height,
                seed=req.seed,
            )
        elif req.model == "vae_gan":
            img_bytes = generate_image_gan(seed=req.seed)
        else:
            raise HTTPException(status_code=400, detail=f"Unknown model: {req.model}")

        # Save to disk + DB
        saved = save_generated_image(
            img_bytes, req.prompt, req.model, req.session_id
        )

        # Save to chat history
        if req.session_id:
            add_message(
                session_id=req.session_id,
                role='user',
                content=req.prompt,
                msg_type='text'
            )
            add_message(
                session_id=req.session_id,
                role='assistant',
                content=saved['filepath'],
                msg_type='image',
                prompt=req.prompt,
                model_used=req.model
            )

        img_b64 = base64.b64encode(img_bytes).decode('utf-8')
        enriched = enrich_prompt(req.prompt)

        return {
            "image_b64"   : img_b64,
            "filepath"    : saved['filepath'],
            "model_used"  : req.model,
            "enriched_prompt": enriched,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Image Captioning ─────────────────────────────────────────────────────────

@app.post("/caption")
def caption(req: CaptionRequest):
    """
    Caption an uploaded image using BLIP2.
    Optionally answer a question about the image.
    """
    try:
        img_bytes = base64.b64decode(req.image_b64)
        result    = caption_image(img_bytes, question=req.question)

        if req.session_id:
            add_message(
                session_id=req.session_id,
                role='assistant',
                content=result,
                msg_type='caption',
                model_used='blip2'
            )

        return {"caption": result, "model_used": "blip2"}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/caption/upload")
async def caption_upload(
    file: UploadFile = File(...),
    session_id: Optional[int] = None,
    question: Optional[str] = None
):
    """Caption an image uploaded as multipart form data."""
    img_bytes = await file.read()
    img_b64   = base64.b64encode(img_bytes).decode('utf-8')
    req       = CaptionRequest(image_b64=img_b64, session_id=session_id, question=question)
    return caption(req)


# ── Chat (Gemini) ─────────────────────────────────────────────────────────────

@app.post("/chat")
def chat(req: ChatRequest):
    """
    Astronomy QA chat using Gemini API.
    Supports multimodal (image + question).
    """
    try:
        history    = get_session_context(req.session_id, max_messages=8)
        image_bytes= base64.b64decode(req.image_b64) if req.image_b64 else None

        # Save user message to history
        add_message(
            session_id=req.session_id,
            role='user',
            content=req.message,
            msg_type='text'
        )

        response = ask_gemini(
            user_message=req.message,
            history=history,
            image_bytes=image_bytes
        )

        # Save assistant response to history
        add_message(
            session_id=req.session_id,
            role='assistant',
            content=response,
            msg_type='text',
            model_used='gemini'
        )

        return {"response": response, "model_used": "gemini"}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Image Gallery ─────────────────────────────────────────────────────────────

@app.get("/gallery")
def gallery(limit: int = 50):
    """Return all generated images with base64 thumbnails."""
    images = get_all_generated_images(limit)
    result = []
    for img in images:
        img['thumbnail_b64'] = image_to_base64(img['filepath'])
        result.append(img)
    return result


# ── Run ───────────────────────────────────────────────────────────────────────

import threading

def pre_download_models():
    print("[Startup] Initiating background model pre-download...")
    try:
        from models import _load_lora_pipeline
        print("[Startup] Downloading Stable Diffusion v1.5 base models...")
        _load_lora_pipeline()
        print("[Startup] Stable Diffusion models ready!")
    except Exception as e:
        print(f"[Startup] Error pre-downloading models: {e}")

@app.on_event("startup")
def startup_event():
    threading.Thread(target=pre_download_models, daemon=True).start()

if __name__ == "__main__":
    print("=" * 55)
    print("  AstroGen Backend starting...")
    print("  API: http://localhost:8001")
    print("  Docs: http://localhost:8001/docs")
    print("=" * 55)
    uvicorn.run(app, host="127.0.0.1", port=8001, log_level="info")

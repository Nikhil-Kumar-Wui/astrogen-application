"""
AstroGen — models.py
Loads trained models from disk. Handles:
  - LoRA fine-tuned Stable Diffusion 1.5  → text-to-image generation
  - VAE-GAN decoder                        → random space image generation
  - BLIP2 fine-tuned                       → image captioning/explanation
All models loaded lazily (only when first used) to save RAM.
ML packages (torch, diffusers) are optional — backend starts without them.
"""

import os
import io
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# ── Optional ML imports (backend runs without them) ───────────────────────────
try:
    import torch
    import numpy as np
    from PIL import Image
    _ML_AVAILABLE = True
    print("[Models] ML packages available (torch, numpy, PIL)")
except ImportError as _e:
    _ML_AVAILABLE = False
    torch = None
    np    = None
    print(f"[Models] ML packages not installed ({_e}). "
          "Backend starts in no-model mode. "
          "Install torch/diffusers to enable image generation.")

# ── Paths ───────────────────────────────────────────────────────────────────
APP_DIR    = os.path.dirname(os.path.dirname(__file__))
MODELS_DIR = os.path.join(APP_DIR, 'models')

LORA_WEIGHTS_PATH  = os.path.join(MODELS_DIR, 'lora', 'astrogen_lora.safetensors')
GAN_ENC_PATH       = os.path.join(MODELS_DIR, 'vae_gan', 'encoder.pt')
GAN_GEN_PATH       = os.path.join(MODELS_DIR, 'vae_gan', 'generator.pt')
BLIP2_PATH         = os.path.join(MODELS_DIR, 'blip2', 'blip2_finetuned')

SD_BASE_MODEL      = 'runwayml/stable-diffusion-v1-5'
BLIP2_BASE_MODEL   = 'Salesforce/blip2-opt-2.7b'

DEVICE = ('cuda' if (_ML_AVAILABLE and torch.cuda.is_available()) else 'cpu')
print(f"[Models] Device: {DEVICE}")

# ── Astronomy Ontology (copy from notebook for prompt enrichment) ───────────
ASTRONOMY_ONTOLOGY = {
    'galaxy'   : {'style_tokens': 'astrophotography, deep field, NASA image'},
    'nebula'   : {'style_tokens': 'Hubble space telescope, false color, NASA image'},
    'star'     : {'style_tokens': 'astronomical observation, telescope image'},
    'planet'   : {'style_tokens': 'NASA spacecraft image, planetary science'},
    'sun'      : {'style_tokens': 'SDO image, solar dynamics observatory, UV wavelength'},
    'aurora'   : {'style_tokens': 'night sky photography, long exposure, vibrant colors'},
    'comet'    : {'style_tokens': 'astronomical photography, NASA APOD'},
    'deep_sky' : {'style_tokens': 'James Webb Space Telescope, JWST, deep field'},
}

SPACE_KEYWORDS = list(ASTRONOMY_ONTOLOGY.keys())


def detect_category(prompt: str) -> str:
    """Auto-detect astronomical category from user prompt."""
    prompt_lower = prompt.lower()
    for cat in SPACE_KEYWORDS:
        if cat in prompt_lower:
            return cat
    # Extra keyword mapping
    keyword_map = {
        'spiral': 'galaxy', 'andromeda': 'galaxy', 'milky way': 'galaxy',
        'orion': 'nebula', 'crab': 'nebula', 'pillars': 'nebula',
        'sunspot': 'sun', 'corona': 'sun', 'flare': 'sun',
        'mars': 'planet', 'saturn': 'planet', 'jupiter': 'planet',
        'northern lights': 'aurora', 'borealis': 'aurora',
        'jwst': 'deep_sky', 'hubble': 'deep_sky', 'webb': 'deep_sky',
    }
    for kw, cat in keyword_map.items():
        if kw in prompt_lower:
            return cat
    return 'deep_sky'  # default


def enrich_prompt(raw_prompt: str) -> str:
    """Add astronomy ontology style tokens to prompt."""
    cat  = detect_category(raw_prompt)
    ont  = ASTRONOMY_ONTOLOGY.get(cat, {})
    style= ont.get('style_tokens', 'NASA APOD, astronomy, high resolution')
    return f"{raw_prompt}. {style}"


# ── Lazy-loaded model registry ───────────────────────────────────────────────
_lora_pipeline  = None
_gan_decoder    = None
_blip2_model    = None
_blip2_processor= None


def get_model_status() -> dict:
    """Check which model weights are available on disk."""
    return {
        'lora_sd'     : os.path.exists(LORA_WEIGHTS_PATH),
        'vae_gan'     : os.path.exists(GAN_GEN_PATH),
        'blip2'       : os.path.exists(BLIP2_PATH),
        'device'      : DEVICE,
        'ml_packages' : _ML_AVAILABLE,
    }


# ── LoRA Stable Diffusion ───────────────────────────────────────────────────

def _load_lora_pipeline():
    global _lora_pipeline
    if not _ML_AVAILABLE:
        raise RuntimeError(
            "torch/diffusers not installed. "
            "Run: pip install torch diffusers transformers safetensors"
        )
    if _lora_pipeline is not None:
        return _lora_pipeline

    print("[Models] Loading LoRA-SD pipeline...")
    from diffusers import StableDiffusionPipeline
    from safetensors.torch import load_file

    dtype = torch.float16 if DEVICE == 'cuda' else torch.float32
    pipeline = StableDiffusionPipeline.from_pretrained(
        SD_BASE_MODEL, torch_dtype=dtype, safety_checker=None
    ).to(DEVICE)
    pipeline.enable_attention_slicing()

    if os.path.exists(LORA_WEIGHTS_PATH):
        print(f"[Models] Loading LoRA weights: {LORA_WEIGHTS_PATH}")
        lora_state = load_file(LORA_WEIGHTS_PATH)
        pipeline.unet.load_state_dict(lora_state, strict=False)
        print("[Models] LoRA weights loaded \u2713")
    else:
        print("[Models] LoRA weights not found - using base SD 1.5")

    _lora_pipeline = pipeline
    return pipeline


def generate_image_lora(
    prompt: str,
    negative_prompt: str = "blurry, low quality, text, watermark, logo",
    num_steps: int = 30,
    guidance_scale: float = 7.5,
    width: int = 512,
    height: int = 512,
    seed: int = None,
) -> bytes:
    """
    Generate astronomical image from text prompt using LoRA fine-tuned SD.
    Returns PNG bytes.
    """
    pipeline = _load_lora_pipeline()
    enriched = enrich_prompt(prompt)

    generator = None
    if seed is not None:
        generator = torch.Generator(device=DEVICE).manual_seed(seed)

    with torch.autocast(DEVICE) if DEVICE == 'cuda' else torch.no_grad():
        result = pipeline(
            enriched,
            negative_prompt=negative_prompt,
            num_inference_steps=num_steps,
            guidance_scale=guidance_scale,
            width=width,
            height=height,
            generator=generator,
        )

    img    = result.images[0]
    buf    = io.BytesIO()
    img.save(buf, format='PNG')
    return buf.getvalue()


# ── VAE-GAN ─────────────────────────────────────────────────────────────────

if _ML_AVAILABLE:
    class _DecoderStub(torch.nn.Module):
        """Minimal decoder matching notebook architecture."""
        def __init__(self, latent_dim=256, base_ch=64, img_size=256):
            super().__init__()
            self.init_size = img_size // 32
            self.base_ch   = base_ch
            self.fc = torch.nn.Linear(latent_dim, base_ch*8 * self.init_size ** 2)
            layers = []
            ch_list = [base_ch*8, base_ch*8, base_ch*4, base_ch*4, base_ch*2, base_ch*2, base_ch, 3]
            strides = [2, 2, 2, 2, 2]
            for i in range(len(strides)):
                layers += [
                    torch.nn.BatchNorm2d(ch_list[i]),
                    torch.nn.ConvTranspose2d(ch_list[i], ch_list[i+1], 4, strides[i], 1),
                    torch.nn.ReLU(True) if i < len(strides)-1 else torch.nn.Tanh()
                ]
            self.net = torch.nn.Sequential(*layers)

        def forward(self, z):
            h = self.fc(z).view(-1, self.base_ch*8, self.init_size, self.init_size)
            return self.net(h)



def _load_gan_decoder():
    global _gan_decoder
    if not _ML_AVAILABLE:
        raise RuntimeError(
            "torch not installed. Run: pip install torch torchvision"
        )
    if _gan_decoder is not None:
        return _gan_decoder

    print("[Models] Loading VAE-GAN decoder...")
    decoder = _DecoderStub(latent_dim=256, base_ch=64, img_size=256).to(DEVICE)

    if os.path.exists(GAN_GEN_PATH):
        state = torch.load(GAN_GEN_PATH, map_location=DEVICE)
        decoder.load_state_dict(state, strict=False)
        decoder.eval()
        print("[Models] VAE-GAN decoder loaded \u2713")
    else:
        print("[Models] GAN weights not found - random noise output")

    _gan_decoder = decoder
    return decoder


def generate_image_gan(seed: int = None) -> bytes:
    """
    Generate random astronomical image using VAE-GAN decoder.
    Returns PNG bytes.
    """
    decoder = _load_gan_decoder()

    if seed is not None:
        torch.manual_seed(seed)

    with torch.no_grad():
        z   = torch.randn(1, 256, device=DEVICE)
        out = decoder(z)
        img_tensor = (out.squeeze(0).clamp(-1, 1) + 1) / 2  # [-1,1] → [0,1]

    import torchvision.transforms as T
    img = T.ToPILImage()(img_tensor.cpu())
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    return buf.getvalue()


# ── BLIP2 Captioning ────────────────────────────────────────────────────────

def _load_blip2():
    global _blip2_model, _blip2_processor
    if not _ML_AVAILABLE:
        raise RuntimeError(
            "torch/transformers not installed. Run: pip install torch transformers"
        )
    if _blip2_model is not None:
        return _blip2_model, _blip2_processor

    print("[Models] Loading BLIP2...")
    from transformers import Blip2Processor, Blip2ForConditionalGeneration

    model_path = BLIP2_PATH if os.path.exists(BLIP2_PATH) else BLIP2_BASE_MODEL
    print(f"[Models] Loading from: {model_path}")

    dtype = torch.float16 if DEVICE == 'cuda' else torch.float32
    processor = Blip2Processor.from_pretrained(model_path)
    model     = Blip2ForConditionalGeneration.from_pretrained(
        model_path, torch_dtype=dtype, device_map='auto'
    )
    model.eval()
    print("[Models] BLIP2 loaded ✓")

    _blip2_model     = model
    _blip2_processor = processor
    return model, processor


def caption_image(img_bytes: bytes, question: str = None) -> str:
    """
    Generate APOD-style caption OR answer question about image.
    Args:
        img_bytes: Raw image bytes (PNG/JPG)
        question:  If None, generate free caption. If str, do VQA.
    Returns: Generated text
    """
    model, processor = _load_blip2()
    img = Image.open(io.BytesIO(img_bytes)).convert('RGB')

    if question:
        prompt = f"Question: {question} Answer:"
        inputs = processor(images=img, text=prompt, return_tensors='pt').to(
            DEVICE, dtype=torch.float16 if DEVICE == 'cuda' else torch.float32)
    else:
        inputs = processor(images=img, return_tensors='pt').to(
            DEVICE, dtype=torch.float16 if DEVICE == 'cuda' else torch.float32)

    with torch.no_grad():
        generated_ids = model.generate(**inputs, max_new_tokens=200)

    caption = processor.decode(generated_ids[0], skip_special_tokens=True).strip()
    return caption

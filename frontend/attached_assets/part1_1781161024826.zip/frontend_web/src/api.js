const BASE = 'http://localhost:8001'

async function req(path, opts = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
  })
  if (!res.ok) {
    const text = await res.text()
    throw new Error(text || `HTTP ${res.status}`)
  }
  return res.json()
}

export const api = {
  getStatus:       ()         => req('/status'),
  getSessions:     ()         => req('/sessions'),
  createSession:   (title)    => req(`/sessions?title=${encodeURIComponent(title)}`, { method: 'POST' }),
  deleteSession:   (id)       => req(`/sessions/${id}`, { method: 'DELETE' }),
  getMessages:     (id)       => req(`/sessions/${id}/messages`),
  generate:        (body)     => req('/generate',  { method: 'POST', body: JSON.stringify(body) }),
  chat:            (body)     => req('/chat',       { method: 'POST', body: JSON.stringify(body) }),
  caption:         (body)     => req('/caption',    { method: 'POST', body: JSON.stringify(body) }),
  getGallery:      (n = 60)   => req(`/gallery?limit=${n}`),
}

/** Convert a local file path returned by the backend into a URL the browser can load */
export function imageUrl(filepath) {
  if (!filepath) return null
  if (filepath.startsWith('data:')) return filepath        // already base64
  const filename = filepath.replace(/\\/g, '/').split('/').pop()
  return `${BASE}/generated/${filename}`
}

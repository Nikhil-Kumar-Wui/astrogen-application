import React, { useEffect, useState } from 'react';
import { api, imageUrl } from '../api';

export default function GalleryModal({ onClose, onImageClick }) {
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadGallery() {
      try {
        const data = await api.getGallery(100);
        setImages(data);
      } catch (err) {
        console.error('Failed to load gallery:', err);
      } finally {
        setLoading(false);
      }
    }
    loadGallery();
  }, []);

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div className="modal-title">🌌 Deep Space Photographic Gallery</div>
          <button className="btn btn-sm btn-secondary" onClick={onClose}>
            ✕ Close
          </button>
        </div>

        <div className="modal-body">
          {loading ? (
            <div className="gallery-empty">
              <div className="thinking-dots">
                <div className="thinking-dot" />
                <div className="thinking-dot" />
                <div className="thinking-dot" />
              </div>
              <p>Scanning data storage archives...</p>
            </div>
          ) : images.length === 0 ? (
            <div className="gallery-empty">
              <div className="gallery-empty-icon">🕳️</div>
              <p>No astronomical captures found in records.</p>
            </div>
          ) : (
            <div className="gallery-grid">
              {images.map((img, idx) => {
                const imgUrl = imageUrl(img.filepath);
                const thumbUrl = img.thumbnail_b64 
                  ? `data:image/png;base64,${img.thumbnail_b64}` 
                  : imgUrl;

                return (
                  <div 
                    key={img.id || idx} 
                    className="gallery-card"
                    onClick={() => onImageClick(imgUrl, img.prompt)}
                  >
                    <img src={thumbUrl} alt={img.prompt || 'Cosmic generation'} />
                    <div className="gallery-card-info">
                      <div className="gallery-card-model">{img.model || 'Unknown'}</div>
                      <div className="gallery-card-prompt" title={img.prompt}>
                        {img.prompt || 'Random Seed'}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

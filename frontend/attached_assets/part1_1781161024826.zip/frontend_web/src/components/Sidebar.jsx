import React from 'react';

export default function Sidebar({
  sessions,
  activeSessionId,
  onSelectSession,
  onCreateSession,
  onDeleteSession,
  onOpenGallery,
  isOnline
}) {
  return (
    <div className="sidebar">
      <div className="sidebar-logo">
        <span className="sidebar-logo-star">✨</span>
        <span className="sidebar-logo-name">AstroGen</span>
      </div>

      <div className="status-pill">
        <div className={`status-dot ${isOnline ? 'online' : 'offline'}`} />
        <span>{isOnline ? 'Telemetry Online' : 'Telemetry Offline'}</span>
      </div>

      <button className="btn btn-primary btn-full" style={{ height: '38px', marginTop: '6px' }} onClick={onCreateSession}>
        + New Conversation
      </button>

      <div className="history-label">History</div>
      
      <div className="session-list">
        {sessions.map((session) => (
          <div
            key={session.id}
            className={`session-item ${session.id === activeSessionId ? 'active' : ''}`}
            onClick={() => onSelectSession(session.id)}
          >
            <div className="session-item-dot" />
            <div className="session-item-text" title={session.title}>
              {session.title}
            </div>
            <button
              className="session-delete"
              onClick={(e) => {
                e.stopPropagation();
                onDeleteSession(session.id);
              }}
              title="Delete expedition"
            >
              ✕
            </button>
          </div>
        ))}
      </div>

      <div className="sidebar-div" />

      <button className="btn btn-secondary btn-full" style={{ height: '36px' }} onClick={onOpenGallery}>
        ⛶ Image Gallery
      </button>
    </div>
  );
}

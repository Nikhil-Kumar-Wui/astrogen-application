import React, { useEffect, useState } from 'react';

export default function StarCanvas() {
  const [stars, setStars] = useState([]);

  useEffect(() => {
    // Generate a fixed set of star parameters so they don't re-render/re-generate randomly on every state update
    const generated = [];
    const count = 120;
    for (let i = 0; i < count; i++) {
      const isBright = Math.random() > 0.85;
      const x = Math.random() * 100;
      const y = Math.random() * 100;
      const size = isBright ? (Math.random() * 2 + 2.5) : (Math.random() * 1.5 + 1);
      const delay = Math.random() * 6;
      const duration = Math.random() * 4 + 3; // 3s to 7s
      const opacityLo = Math.random() * 0.15;
      const opacityHi = Math.random() * 0.65 + 0.35;
      
      let color = '#d3cbfb'; // default purple tint
      const colorRand = Math.random();
      if (colorRand > 0.8) {
        color = '#a2d2ff'; // blue
      } else if (colorRand > 0.6) {
        color = '#ffccd5'; // soft pink/red
      } else if (colorRand > 0.4) {
        color = '#ffffff'; // pure white
      }

      generated.push({
        id: i,
        isBright,
        style: {
          left: `${x}%`,
          top: `${y}%`,
          '--sz': `${size}px`,
          '--dur': `${duration}s`,
          '--del': `${delay}s`,
          '--lo': opacityLo,
          '--hi': opacityHi,
          '--col': color,
          '--cross': isBright ? `${Math.floor(Math.random() * 6) + 10}px` : undefined,
        }
      });
    }
    setStars(generated);
  }, []);

  return (
    <div className="star-canvas">
      {stars.map((star) => (
        <div
          key={star.id}
          className={`star ${star.isBright ? 'bright' : ''}`}
          style={star.style}
        />
      ))}
    </div>
  );
}

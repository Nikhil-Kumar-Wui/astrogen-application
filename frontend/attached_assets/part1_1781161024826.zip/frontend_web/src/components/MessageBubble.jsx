import React from 'react';
import { imageUrl } from '../api';

export default function MessageBubble({ message, onImageClick }) {
  const isUser = message.role === 'user';
  const name = isUser ? 'Expedition Pilot' : 'AstroGen AI';
  
  // Format model badges beautifully
  const getModelBadge = (model) => {
    if (!model) return null;
    switch (model.toLowerCase()) {
      case 'lora_sd':
        return 'LoRA Stable Diffusion';
      case 'vae_gan':
        return 'VAE-GAN Decoder';
      case 'gemini':
        return 'Gemini Pro';
      case 'blip2':
        return 'BLIP-2 Vision';
      default:
        return model.toUpperCase();
    }
  };

  // Format timestamp
  const formatTime = (ts) => {
    if (!ts) return '';
    try {
      const date = new Date(ts);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      return ts;
    }
  };

  return (
    <div className={`message ${isUser ? 'user' : 'assistant'}`}>
      <div className="msg-header">
        <span className="msg-name">{name}</span>
        {message.model_used && (
          <span className="msg-badge">{getModelBadge(message.model_used)}</span>
        )}
        <span className="msg-ts">{formatTime(message.timestamp)}</span>
      </div>

      {message.msg_type === 'image' ? (
        <div className="msg-image">
          <img 
            src={imageUrl(message.content)} 
            alt={message.prompt || 'Generated astronomical image'} 
            onClick={() => onImageClick(imageUrl(message.content), message.prompt)}
            style={{ cursor: 'pointer' }}
          />
          {message.prompt && (
            <div className="msg-image-caption">
              <strong>Prompt:</strong> "{message.prompt}"
            </div>
          )}
          <div className="msg-image-actions">
            <button 
              className="btn btn-xs btn-secondary"
              onClick={() => {
                navigator.clipboard.writeText(message.prompt || '');
              }}
            >
              📋 Copy Prompt
            </button>
            <a 
              href={imageUrl(message.content)} 
              download={`astrogen-${Date.now()}.png`}
              target="_blank"
              rel="noreferrer"
              className="btn btn-xs btn-secondary"
              style={{ textDecoration: 'none' }}
            >
              💾 Save Image
            </a>
          </div>
        </div>
      ) : (
        <div className="msg-body">
          {message.content}
        </div>
      )}
    </div>
  );
}

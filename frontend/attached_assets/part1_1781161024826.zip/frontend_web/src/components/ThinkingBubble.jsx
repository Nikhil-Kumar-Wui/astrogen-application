import React from 'react';

export default function ThinkingBubble({ text = 'AstroGen AI is processing...' }) {
  return (
    <div className="thinking">
      <div className="thinking-dots">
        <div className="thinking-dot" />
        <div className="thinking-dot" />
        <div className="thinking-dot" />
      </div>
      <span>{text}</span>
    </div>
  );
}

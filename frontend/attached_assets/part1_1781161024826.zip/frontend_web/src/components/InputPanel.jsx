import React, { useRef, useState } from 'react';

export default function InputPanel({ onSend, isLoading }) {
  const [text, setText] = useState('');
  const [model, setModel] = useState('lora_sd');
  const [imageB64, setImageB64] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const fileInputRef = useRef(null);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
        const base64Data = reader.result.split(',')[1];
        setImageB64(base64Data);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current.click();
  };

  const handleClearImage = () => {
    setImagePreview(null);
    setImageB64(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSend = () => {
    const trimmedText = text.trim();
    if (!trimmedText && !imageB64) return;

    onSend({
      text: trimmedText,
      model,
      imageB64
    });

    // Reset input fields
    setText('');
    handleClearImage();
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="input-panel">
      <div className="input-controls">
        <span className="input-label">Model</span>
        <select 
          className="model-select" 
          value={model} 
          onChange={(e) => setModel(e.target.value)}
          disabled={isLoading}
        >
          <option value="lora_sd">LoRA-SD — Text to Image</option>
          <option value="vae_gan">VAE-GAN — Random Generation</option>
          <option value="blip2">BLIP2 — Image Captioning</option>
          <option value="gemini">Gemini — Astronomy Chat</option>
        </select>

        <div className="flex-1" />

        <input 
          type="file" 
          ref={fileInputRef} 
          style={{ display: 'none' }} 
          accept="image/*"
          onChange={handleFileChange}
        />
        
        <button 
          className="btn btn-sm btn-secondary" 
          onClick={handleUploadClick}
          disabled={isLoading}
        >
          📷 Upload Image
        </button>

        {imagePreview && (
          <button 
            className="btn btn-sm btn-secondary" 
            onClick={handleClearImage}
            disabled={isLoading}
          >
            Clear
          </button>
        )}
      </div>

      {imagePreview && (
        <div className="input-preview">
          <img src={imagePreview} alt="Upload preview" />
          <span>Image ready for Gemini analysis / BLIP-2 captioning</span>
        </div>
      )}

      <div className="input-row">
        <textarea
          className="input-textarea"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={
            model === 'vae_gan'
              ? 'Click Send to generate a random deep space image using VAE-GAN...'
              : 'Describe a galaxy, nebula or stellar object to generate... or ask an astronomy question.'
          }
          disabled={isLoading}
        />
        <button 
          className="btn btn-primary input-send" 
          onClick={handleSend}
          disabled={isLoading || (!text.trim() && !imageB64)}
        >
          {isLoading ? 'Generating...' : 'Send'}
        </button>
      </div>

      <div className="input-hint">
        Ctrl+Enter to send &middot; Upload an image to caption or analyze it
      </div>
    </div>
  );
}

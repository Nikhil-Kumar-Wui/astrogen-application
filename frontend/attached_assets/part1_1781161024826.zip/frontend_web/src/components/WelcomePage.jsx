import React from 'react';

export default function WelcomePage({ onCreateSession }) {
  return (
    <div className="welcome">
      <div className="welcome-bg" />
      <div className="welcome-hero">
        <div className="welcome-orb">🔭</div>
        <h1 className="welcome-title">ASTROGEN</h1>
        <div className="welcome-sub">AI Deep Space Image Studio</div>
        <p className="welcome-desc">
          Generate cosmic wonders with Stable Diffusion and VAE-GAN models, caption deep space captures with BLIP2, and chat with Gemini to explore the mysteries of the universe.
        </p>

        <div className="feature-strip">
          <div className="feature-item active">
            <div className="feature-icon">✨</div>
            <div className="feature-name">Cosmic Gen</div>
            <div className="feature-desc">LoRA Stable Diffusion & VAE-GAN decoders</div>
          </div>
          <div className="feature-item active">
            <div className="feature-icon">👁️</div>
            <div className="feature-name">Vision BLIP2</div>
            <div className="feature-desc">Analyze and caption uploaded cosmic images</div>
          </div>
          <div className="feature-item active">
            <div className="feature-icon">💬</div>
            <div className="feature-name">Gemini Chat</div>
            <div className="feature-desc">Ask queries and discuss space physics</div>
          </div>
        </div>

        <div className="stats-strip">
          <div className="stat-item">
            <div className="stat-value">512px</div>
            <div className="stat-label">Generation Resolution</div>
          </div>
          <div className="stat-item">
            <div className="stat-value">100%</div>
            <div className="stat-label">Local Model Execution</div>
          </div>
          <div className="stat-item">
            <div className="stat-value">Gemini 1.5</div>
            <div className="stat-label">AI Explanations</div>
          </div>
        </div>

        <button className="btn btn-primary" onClick={onCreateSession}>
          ✨ Initiate New Expedition
        </button>
      </div>
    </div>
  );
}

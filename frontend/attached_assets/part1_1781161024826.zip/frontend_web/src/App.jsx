import React, { useEffect, useState, useRef } from 'react';
import StarCanvas from './components/StarCanvas';
import Sidebar from './components/Sidebar';
import WelcomePage from './components/WelcomePage';
import MessageBubble from './components/MessageBubble';
import InputPanel from './components/InputPanel';
import GalleryModal from './components/GalleryModal';
import ThinkingBubble from './components/ThinkingBubble';
import { api } from './api';

export default function App() {
  const [sessions, setSessions] = useState([]);
  const [activeSessionId, setActiveSessionId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingText, setLoadingText] = useState('');
  const [isOnline, setIsOnline] = useState(false);
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState(null);

  const messagesEndRef = useRef(null);

  // Poll backend status and load sessions
  useEffect(() => {
    async function checkStatus() {
      try {
        await api.getStatus();
        setIsOnline(true);
      } catch (e) {
        setIsOnline(false);
      }
    }

    checkStatus();
    loadSessions();

    const interval = setInterval(checkStatus, 5000);
    return () => clearInterval(interval);
  }, []);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  async function loadSessions() {
    try {
      const data = await api.getSessions();
      setSessions(data);
      if (data.length > 0 && !activeSessionId) {
        // Don't auto-select to keep WelcomePage as start
      }
    } catch (e) {
      console.error('Error loading sessions:', e);
    }
  }

  async function handleSelectSession(id) {
    setActiveSessionId(id);
    try {
      const msgs = await api.getMessages(id);
      setMessages(msgs);
    } catch (e) {
      console.error('Error loading messages:', e);
    }
  }

  async function handleCreateSession() {
    try {
      const name = `Expedition ${new Date().toLocaleDateString()}`;
      const res = await api.createSession(name);
      await loadSessions();
      handleSelectSession(res.session_id);
    } catch (e) {
      console.error('Error creating session:', e);
    }
  }

  async function handleDeleteSession(id) {
    try {
      await api.deleteSession(id);
      if (activeSessionId === id) {
        setActiveSessionId(null);
        setMessages([]);
      }
      loadSessions();
    } catch (e) {
      console.error('Error deleting session:', e);
    }
  }

  async function handleSend({ text, model, imageB64 }) {
    let sid = activeSessionId;
    if (!sid) {
      // Auto-create session if sending from Welcome Page
      try {
        const name = text ? (text.slice(0, 24) + '...') : 'Image Capture';
        const res = await api.createSession(name);
        sid = res.session_id;
        setActiveSessionId(sid);
        await loadSessions();
      } catch (e) {
        console.error('Error creating auto session:', e);
        return;
      }
    }

    setIsLoading(true);

    // Dynamic loader text based on model selection
    if (model === 'lora_sd') setLoadingText('Guiding Stable Diffusion UNet denoising...');
    else if (model === 'vae_gan') setLoadingText('Sampling latent space via VAE-GAN...');
    else if (model === 'blip2') setLoadingText('BLIP-2 reading image features...');
    else setLoadingText('Calling Gemini orbital mainframe...');

    try {
      if (model === 'lora_sd' || model === 'vae_gan') {
        // Generate Image
        await api.generate({
          prompt: text || 'Deep space cosmic nebula',
          model,
          session_id: sid
        });
      } else if (model === 'blip2') {
        // Caption
        if (imageB64) {
          await api.caption({
            image_b64: imageB64,
            question: text || null,
            session_id: sid
          });
        } else {
          // If no image, default to standard chat behavior or warning
          alert('Please upload an image to caption or analyze.');
          setIsLoading(false);
          return;
        }
      } else {
        // Gemini Chat
        await api.chat({
          message: text,
          session_id: sid,
          image_b64: imageB64 || null
        });
      }

      // Re-fetch messages from DB to show updated chat log
      const msgs = await api.getMessages(sid);
      setMessages(msgs);
    } catch (e) {
      console.error('Error during send:', e);
      // Append local error message
      setMessages((prev) => [
        ...prev,
        {
          id: 'err-' + Date.now(),
          role: 'assistant',
          content: `Transmission Error: ${e.message}`,
          msg_type: 'text',
          model_used: model,
          timestamp: new Date().toISOString()
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  }

  const activeSession = sessions.find((s) => s.id === activeSessionId);

  return (
    <div className="app">
      <StarCanvas />
      
      <Sidebar
        sessions={sessions}
        activeSessionId={activeSessionId}
        onSelectSession={handleSelectSession}
        onCreateSession={handleCreateSession}
        onDeleteSession={handleDeleteSession}
        onOpenGallery={() => setIsGalleryOpen(true)}
        isOnline={isOnline}
      />

      <div className="main-content">
        {!activeSessionId ? (
          <WelcomePage onCreateSession={handleCreateSession} />
        ) : (
          <div className="chat-page">
            <div className="chat-header">
              <span className="chat-header-icon">📡</span>
              <span className="chat-header-title">{activeSession?.title}</span>
            </div>

            <div className="messages">
              {messages.length === 0 && !isLoading && (
                <div style={{ margin: 'auto', textAlign: 'center', color: 'var(--silver-3)' }}>
                  <p style={{ fontSize: '24px', marginBottom: '8px' }}>📡</p>
                  <p>Channel open. Describe astronomical features or upload images to begin telemetry.</p>
                </div>
              )}
              
              {messages.map((msg) => (
                <MessageBubble
                  key={msg.id}
                  message={msg}
                  onImageClick={(url, prompt) => setPreviewImage({ url, prompt })}
                />
              ))}

              {isLoading && <ThinkingBubble text={loadingText} />}
              <div ref={messagesEndRef} />
            </div>

            <InputPanel onSend={handleSend} isLoading={isLoading} />
          </div>
        )}
      </div>

      {isGalleryOpen && (
        <GalleryModal
          onClose={() => setIsGalleryOpen(false)}
          onImageClick={(url, prompt) => {
            setPreviewImage({ url, prompt });
          }}
        />
      )}

      {/* Lightbox Modal for Full Image Preview */}
      {previewImage && (
        <div 
          className="modal-overlay" 
          onClick={() => setPreviewImage(null)}
          style={{ zIndex: 200 }}
        >
          <div 
            style={{
              position: 'relative',
              maxWidth: '90vw',
              maxHeight: '90vh',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              animation: 'modal-in var(--normal) var(--ease)'
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <img 
              src={previewImage.url} 
              alt={previewImage.prompt || 'Cosmic view'} 
              style={{
                maxWidth: '85vw',
                maxHeight: '80vh',
                borderRadius: '12px',
                border: '1px solid var(--border-2)',
                boxShadow: '0 20px 50px rgba(0,0,0,0.85)',
                objectFit: 'contain'
              }}
            />
            {previewImage.prompt && (
              <p style={{
                color: 'var(--silver)',
                marginTop: '15px',
                background: 'rgba(10, 10, 26, 0.85)',
                padding: '8px 16px',
                borderRadius: '8px',
                border: '1px solid var(--border)',
                maxWidth: '600px',
                textAlign: 'center',
                fontSize: '13.5px',
                backdropFilter: 'blur(8px)'
              }}>
                {previewImage.prompt}
              </p>
            )}
            <button 
              className="btn btn-sm btn-secondary" 
              style={{
                position: 'absolute',
                top: '-45px',
                right: '0',
                background: 'rgba(10, 10, 26, 0.8)',
                border: '1px solid var(--border)'
              }}
              onClick={() => setPreviewImage(null)}
            >
              ✕ Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

import sys
import os
import time
import socket
import subprocess
from PyQt6.QtCore import QUrl
from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
from PyQt6.QtWebEngineWidgets import QWebEngineView

# Group taskbar items correctly on Windows under AstroGen instead of Python
if sys.platform == 'win32':
    try:
        import ctypes
        myappid = 'com.astrogen.studio.v1'
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
    except Exception as e:
        print(f"Failed to set AppUserModelID: {e}")

VITE_URL = "http://127.0.0.1:5173"

def is_port_open(ip, port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(0.5)
    try:
        s.connect((ip, int(port)))
        s.close()
        return True
    except Exception:
        return False

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AstroGen · AI Deep Space Image Studio")
        self.resize(1200, 800)
        self.setMinimumSize(950, 650)
        
        # Set Window Icon
        logo_path = os.path.join(os.path.dirname(__file__), "logo.png")
        if os.path.exists(logo_path):
            self.setWindowIcon(QIcon(logo_path))

        # WebEngine setup
        self.browser = QWebEngineView()
        
        # Disable context menu or customize if needed
        self.browser.setContextMenuPolicy(sys.modules['PyQt6.QtCore'].Qt.ContextMenuPolicy.NoContextMenu)
        
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.browser)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

        # Load url
        self.browser.setUrl(QUrl(VITE_URL))

    def closeEvent(self, event):
        # Clean up any child processes or just exit
        super().closeEvent(event)

def main():
    # Wait for Vite dev server (max 10 seconds)
    print("Waiting for Vite dev server on port 5173...")
    for _ in range(20):
        if is_port_open("127.0.0.1", 5173):
            print("Vite server found. Launching Qt window...")
            break
        time.sleep(0.5)
    else:
        print("Warning: Vite dev server not detected on port 5173. Launching anyway...")

    app = QApplication(sys.argv)
    app.setApplicationName("AstroGen")
    app.setApplicationDisplayName("AstroGen")
    
    logo_path = os.path.join(os.path.dirname(__file__), "logo.png")
    if os.path.exists(logo_path):
        app.setWindowIcon(QIcon(logo_path))
        
    window = MainWindow()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()

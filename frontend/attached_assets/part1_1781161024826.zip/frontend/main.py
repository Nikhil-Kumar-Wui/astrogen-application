# -*- coding: utf-8 -*-
"""
AstroGen - Deep Space Observatory UI v4
Performance: cached bg pixmap, stars only repaint overlay.
Stars: bright focal stars in corners only. Lofi indigo palette.
"""

import sys, os, math, random, base64, requests
from datetime import datetime
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTextEdit, QScrollArea, QFrame,
    QFileDialog, QComboBox, QStackedWidget, QListWidget, QListWidgetItem,
    QDialog, QGridLayout, QSizePolicy,
)
from PyQt6.QtCore import (
    Qt, QThread, pyqtSignal, QTimer, QPointF, QRectF, QSize,
)
from PyQt6.QtGui import (
    QPixmap, QColor, QPainter, QLinearGradient, QRadialGradient,
    QBrush, QPen, QPalette, QCursor, QKeySequence, QImage,
)

API_BASE = "http://localhost:8001"

C = {
    'void'      : '#040408',
    'deep'      : '#060610',
    'surface'   : '#0b0b1c',
    'surface2'  : '#0f0f24',
    'surface3'  : '#141438',
    'border'    : '#1c1c40',
    'border2'   : '#2e2e72',
    'purple'    : '#7c6af0',
    'purple2'   : '#9d8ef7',
    'purple_dim': '#3a316e',
    'purple_bg' : '#140f30',
    'silver'    : '#e4e4f4',
    'silver2'   : '#8888b0',
    'silver3'   : '#48486a',
    'green'     : '#4ade80',
    'red'       : '#f87171',
}

FONT = "'Segoe UI', 'SF Pro Display', sans-serif"

GLOBAL_STYLE = f"""
QMainWindow, QWidget {{
    background-color: {C['deep']};
    color: {C['silver']};
    font-family: {FONT};
    font-size: 13px;
}}
QScrollBar:vertical {{
    background: transparent; width: 5px;
}}
QScrollBar::handle:vertical {{
    background: {C['border2']}; border-radius: 2px; min-height: 20px;
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar:horizontal {{ background: transparent; height: 5px; }}
QScrollBar::handle:horizontal {{
    background: {C['border2']}; border-radius: 2px;
}}
QToolTip {{
    background: {C['surface2']}; color: {C['silver']};
    border: 1px solid {C['border2']}; border-radius: 6px; padding: 5px 10px;
}}
"""


# ─────────────────────────────────────────────────────────────────────────────
#  STAR CANVAS  — performance-optimised
#  Background gradient cached as QPixmap (repainted only on resize).
#  Stars drawn as overlay every 80ms (12fps) — smooth, not laggy.
#  Bright focal stars restricted to corner zones, away from text.
# ─────────────────────────────────────────────────────────────────────────────

class StarCanvas(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self._rng   = random.Random(17)
        self._stars = []
        self._bg    = None        # cached background QPixmap
        self._phase = 0.0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(80)    # 12 fps — smooth but cheap

    def resizeEvent(self, e):
        self._build_bg()
        self._build_stars()
        super().resizeEvent(e)

    # ── Build background (only on resize) ───────────────────────────────────

    def _build_bg(self):
        w, h = self.width(), self.height()
        if w < 10 or h < 10:
            return
        self._bg = QPixmap(w, h)
        p = QPainter(self._bg)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Base gradient
        bg = QLinearGradient(0, 0, 0, h)
        bg.setColorAt(0.00, QColor('#030307'))
        bg.setColorAt(0.40, QColor('#05050f'))
        bg.setColorAt(0.70, QColor('#06060e'))
        bg.setColorAt(1.00, QColor('#040408'))
        p.fillRect(0, 0, w, h, bg)

        # Nebula glows — static, painted once
        self._draw_nebula(p, w*0.80, h*0.15, w*0.45, QColor(55, 38, 135, 22))
        self._draw_nebula(p, w*0.12, h*0.72, w*0.38, QColor(28, 18, 90, 17))
        self._draw_nebula(p, w*0.50, h*0.88, w*0.30, QColor(18, 10, 65, 13))
        self._draw_nebula(p, w*0.22, h*0.08, w*0.26, QColor(45, 28, 110, 12))
        self._draw_nebula(p, w*0.88, h*0.78, w*0.20, QColor(22, 12, 72, 10))

        # Milky Way band — faint diagonal
        band = QLinearGradient(0, h*0.3, w, h*0.7)
        band.setColorAt(0.0,  QColor(0, 0, 0, 0))
        band.setColorAt(0.35, QColor(35, 22, 80, 9))
        band.setColorAt(0.50, QColor(50, 32, 100, 14))
        band.setColorAt(0.65, QColor(35, 22, 80, 9))
        band.setColorAt(1.0,  QColor(0, 0, 0, 0))
        p.fillRect(0, 0, w, h, band)
        p.end()

    def _draw_nebula(self, p, cx, cy, r, col):
        g = QRadialGradient(cx, cy, r)
        g.setColorAt(0.0, col)
        g.setColorAt(1.0, QColor(0, 0, 0, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(g))
        p.drawEllipse(QPointF(cx, cy), r, r)

    # ── Build stars (only on resize) ─────────────────────────────────────────

    def _build_stars(self):
        w, h = self.width(), self.height()
        if w < 10 or h < 10:
            return
        rng = self._rng
        self._stars = []

        # Tiny background stars — uniform across canvas
        for _ in range(200):
            col = rng.choice(['white', 'cool', 'warm'])
            self._stars.append(dict(
                x=rng.uniform(0, w), y=rng.uniform(0, h),
                r=rng.uniform(0.3, 0.85),
                ab=rng.uniform(0.12, 0.50),
                aa=rng.uniform(0.05, 0.18),
                sp=rng.uniform(0.3, 1.5),
                ph=rng.uniform(0, math.tau),
                kind='tiny', col=col,
            ))

        # Medium stars
        for _ in range(55):
            col = rng.choice(['white', 'cool', 'purple'])
            self._stars.append(dict(
                x=rng.uniform(0, w), y=rng.uniform(0, h),
                r=rng.uniform(0.85, 1.8),
                ab=rng.uniform(0.30, 0.75),
                aa=rng.uniform(0.10, 0.28),
                sp=rng.uniform(0.5, 2.5),
                ph=rng.uniform(0, math.tau),
                kind='medium', col=col,
            ))

        # Bright focal stars — ONLY in corner zones (top/bottom 20% + left/right 20%)
        # This keeps them away from the central description text
        corner_zones = [
            (0,        0,        w*0.22, h*0.30),   # top-left
            (w*0.78,   0,        w,      h*0.30),   # top-right
            (0,        h*0.70,   w*0.22, h),         # bottom-left
            (w*0.78,   h*0.70,   w,      h),         # bottom-right
            (w*0.38,   0,        w*0.62, h*0.12),   # top center strip
            (w*0.38,   h*0.88,   w*0.62, h),         # bottom center strip
            (0,        h*0.35,   w*0.10, h*0.65),   # left edge middle
            (w*0.90,   h*0.35,   w,      h*0.65),   # right edge middle
        ]
        for _ in range(10):
            zone = rng.choice(corner_zones)
            x1, y1, x2, y2 = zone
            if x2 <= x1 or y2 <= y1:
                continue
            col = rng.choice(['white', 'cool', 'purple'])
            self._stars.append(dict(
                x=rng.uniform(x1, x2), y=rng.uniform(y1, y2),
                r=rng.uniform(1.6, 2.8),
                ab=rng.uniform(0.55, 0.92),
                aa=rng.uniform(0.15, 0.35),
                sp=rng.uniform(1.0, 3.0),
                ph=rng.uniform(0, math.tau),
                kind='bright', col=col,
                cl=rng.uniform(5, 12),
            ))

    def _tick(self):
        self._phase += 0.08
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        # Draw cached background
        if self._bg:
            p.drawPixmap(0, 0, self._bg)

        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        t = self._phase

        for s in self._stars:
            af = s['ab'] + s['aa'] * math.sin(t * s['sp'] + s['ph'])
            af = max(0.0, min(1.0, af))
            a  = int(af * 255)

            col = s['col']
            if col == 'cool':
                c = QColor(195, 210, 255, a)
            elif col == 'purple':
                c = QColor(170, 150, 255, a)
            elif col == 'warm':
                c = QColor(255, 248, 220, a)
            else:
                c = QColor(230, 230, 255, a)

            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(c))

            if s['kind'] == 'bright' and af > 0.45:
                cl = s['cl']
                # Glow halo
                g = QRadialGradient(s['x'], s['y'], cl * 2.2)
                g.setColorAt(0.0, QColor(c.red(), c.green(), c.blue(), int(af * 70)))
                g.setColorAt(1.0, QColor(0, 0, 0, 0))
                p.setBrush(QBrush(g))
                p.drawEllipse(QPointF(s['x'], s['y']), cl * 2.2, cl * 2.2)
                # Cross
                pen = QPen(QColor(c.red(), c.green(), c.blue(), int(af * 200)))
                pen.setWidthF(0.7)
                p.setPen(pen)
                p.setBrush(Qt.BrushStyle.NoBrush)
                cx, cy = s['x'], s['y']
                p.drawLine(QPointF(cx - cl, cy), QPointF(cx + cl, cy))
                p.drawLine(QPointF(cx, cy - cl), QPointF(cx, cy + cl))
                d = cl * 0.38
                pen2 = QPen(QColor(c.red(), c.green(), c.blue(), int(af * 120)))
                pen2.setWidthF(0.4)
                p.setPen(pen2)
                p.drawLine(QPointF(cx-d, cy-d), QPointF(cx+d, cy+d))
                p.drawLine(QPointF(cx-d, cy+d), QPointF(cx+d, cy-d))

            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(c))
            p.drawEllipse(QPointF(s['x'], s['y']), s['r'], s['r'])

        p.end()


# ─────────────────────────────────────────────────────────────────────────────
#  API WORKER
# ─────────────────────────────────────────────────────────────────────────────

class APIWorker(QThread):
    result_ready = pyqtSignal(dict)
    error_signal = pyqtSignal(str)

    def __init__(self, endpoint, method='POST', payload=None, files=None, params=None):
        super().__init__()
        self.endpoint = endpoint
        self.method   = method
        self.payload  = payload or {}
        self.files    = files
        self.params   = params or {}

    def run(self):
        try:
            url = f"{API_BASE}{self.endpoint}"
            if self.method == 'POST':
                r = (requests.post(url, files=self.files, params=self.params, timeout=300)
                     if self.files else
                     requests.post(url, json=self.payload, timeout=300))
            elif self.method == 'GET':
                r = requests.get(url, params=self.params, timeout=30)
            elif self.method == 'DELETE':
                r = requests.delete(url, timeout=10)
            elif self.method == 'PUT':
                r = requests.put(url, json=self.payload, timeout=10)
            else:
                r = requests.get(url, timeout=30)

            if r.status_code == 200:
                self.result_ready.emit(r.json())
            else:
                self.error_signal.emit(f"API {r.status_code}: {r.text[:200]}")
        except requests.exceptions.ConnectionError:
            self.error_signal.emit("Cannot connect to backend. Make sure AstroGen is running.")
        except Exception as e:
            self.error_signal.emit(str(e))


# ─────────────────────────────────────────────────────────────────────────────
#  BUTTON
# ─────────────────────────────────────────────────────────────────────────────

class Btn(QPushButton):
    def __init__(self, text, primary=False, small=False):
        super().__init__(text)
        self.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        pad = "7px 16px" if small else "10px 22px"
        fsz = "12px"    if small else "13px"
        if primary:
            self.setStyleSheet(f"""
                QPushButton {{
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                        stop:0 {C['purple_dim']}, stop:0.5 {C['purple']}, stop:1 {C['purple_dim']});
                    color: #fff; border: none; border-radius: 8px;
                    padding: {pad}; font-size: {fsz}; font-weight: 600;
                }}
                QPushButton:hover {{
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                        stop:0 {C['purple']}, stop:0.5 {C['purple2']}, stop:1 {C['purple']});
                }}
                QPushButton:pressed {{ background: {C['purple_dim']}; }}
                QPushButton:disabled {{ background: {C['border']}; color: {C['silver3']}; }}
            """)
        else:
            self.setStyleSheet(f"""
                QPushButton {{
                    background: {C['surface2']}; color: {C['silver2']};
                    border: 1px solid {C['border']}; border-radius: 8px;
                    padding: {pad}; font-size: {fsz};
                }}
                QPushButton:hover {{
                    background: {C['surface3']}; color: {C['silver']};
                    border-color: {C['border2']};
                }}
                QPushButton:pressed {{ background: {C['border']}; }}
            """)


# ─────────────────────────────────────────────────────────────────────────────
#  THINKING BUBBLE
# ─────────────────────────────────────────────────────────────────────────────

class ThinkingBubble(QFrame):
    def __init__(self):
        super().__init__()
        self.setStyleSheet(f"""
            QFrame {{
                background: {C['surface']};
                border: 1px solid {C['border']};
                border-left: 3px solid {C['purple_dim']};
                border-radius: 10px; margin: 2px 0;
            }}
        """)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(16, 12, 16, 12)
        self._lbl = QLabel("  AstroGen is thinking")
        self._lbl.setStyleSheet(f"color: {C['silver3']}; font-size: 13px;")
        lay.addWidget(self._lbl)
        lay.addStretch()
        self._step = 0
        self._t = QTimer()
        self._t.timeout.connect(self._tick)
        self._t.start(500)

    def _tick(self):
        frames = [
            "  AstroGen is thinking",
            "  AstroGen is thinking  \u25cf",
            "  AstroGen is thinking  \u25cf \u25cf",
            "  AstroGen is thinking  \u25cf \u25cf \u25cf",
        ]
        self._step = (self._step + 1) % 4
        self._lbl.setText(frames[self._step])

    def stop(self):
        self._t.stop()


# ─────────────────────────────────────────────────────────────────────────────
#  MESSAGE BUBBLE
# ─────────────────────────────────────────────────────────────────────────────

class MessageBubble(QFrame):
    def __init__(self, role, content, msg_type='text', model_used=None, timestamp=None):
        super().__init__()
        self.role = role
        self.msg_type = msg_type
        self._build(content, model_used, timestamp)

    def _build(self, content, model_used, timestamp):
        is_user = self.role == 'user'
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 12, 16, 12)
        lay.setSpacing(8)

        if is_user:
            self.setStyleSheet(f"""
                QFrame {{
                    background: {C['purple_bg']};
                    border: 1px solid {C['border']};
                    border-left: 3px solid {C['purple']};
                    border-radius: 10px; margin: 2px 0;
                }}
            """)
        else:
            self.setStyleSheet(f"""
                QFrame {{
                    background: {C['surface']};
                    border: 1px solid {C['border']};
                    border-left: 3px solid {C['border2']};
                    border-radius: 10px; margin: 2px 0;
                }}
            """)

        hdr = QHBoxLayout()
        hdr.setSpacing(10)
        name = QLabel("You" if is_user else "AstroGen")
        name.setStyleSheet(f"""
            color: {C['purple2'] if is_user else C['silver2']};
            font-weight: 700; font-size: 12px; letter-spacing: 0.5px;
        """)
        hdr.addWidget(name)

        if model_used and not is_user:
            badge = QLabel(f"  {model_used.upper()}  ")
            badge.setStyleSheet(f"""
                color: {C['purple_dim']};
                background: {C['surface3']};
                border: 1px solid {C['border2']};
                border-radius: 4px; font-size: 10px; padding: 1px 0;
            """)
            hdr.addWidget(badge)
        hdr.addStretch()

        if timestamp:
            try:
                ts = datetime.fromisoformat(timestamp).strftime('%H:%M')
                tl = QLabel(ts)
                tl.setStyleSheet(f"color: {C['silver3']}; font-size: 11px;")
                hdr.addWidget(tl)
            except Exception:
                pass
        lay.addLayout(hdr)

        if self.msg_type == 'image':
            img_lbl = QLabel()
            img_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            if os.path.exists(content):
                pix = QPixmap(content).scaled(
                    500, 500, Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation)
                img_lbl.setPixmap(pix)
                img_lbl.setStyleSheet(f"""
                    border: 1px solid {C['border2']}; border-radius: 8px;
                    padding: 4px; background: {C['void']};
                """)
            else:
                img_lbl.setText("[Image not found]")
                img_lbl.setStyleSheet(f"color: {C['silver3']};")
            save_btn = Btn("Save Image", small=True)
            save_btn.clicked.connect(lambda: self._save(content))
            lay.addWidget(img_lbl)
            lay.addWidget(save_btn)
        else:
            txt = QLabel(content)
            txt.setWordWrap(True)
            txt.setTextInteractionFlags(
                Qt.TextInteractionFlag.TextSelectableByMouse |
                Qt.TextInteractionFlag.TextSelectableByKeyboard)
            txt.setStyleSheet(f"""
                color: {C['silver']}; font-size: 13px; line-height: 1.7;
                background: transparent; border: none;
            """)
            lay.addWidget(txt)

    def _save(self, filepath):
        dest, _ = QFileDialog.getSaveFileName(
            self, "Save Image", os.path.basename(filepath),
            "PNG (*.png);;JPEG (*.jpg)")
        if dest:
            import shutil
            shutil.copy2(filepath, dest)


# ─────────────────────────────────────────────────────────────────────────────
#  SIDEBAR
# ─────────────────────────────────────────────────────────────────────────────

class Sidebar(QWidget):
    session_selected      = pyqtSignal(int, str)
    new_session_requested = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.setFixedWidth(248)
        self.setStyleSheet(f"QWidget {{ background: {C['surface']}; border-right: 1px solid {C['border']}; }}")
        self._build()

    def _build(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 18, 14, 16)
        lay.setSpacing(6)

        # Logo
        logo_row = QHBoxLayout()
        logo_row.setSpacing(10)
        ic = QLabel("\u2736")
        ic.setStyleSheet(f"color: {C['purple2']}; font-size: 20px; background: transparent; border: none;")
        logo_row.addWidget(ic)
        nm = QLabel("AstroGen")
        nm.setStyleSheet(f"color: {C['silver']}; font-size: 17px; font-weight: 800; letter-spacing: 1.5px; background: transparent; border: none;")
        logo_row.addWidget(nm)
        logo_row.addStretch()
        lay.addLayout(logo_row)

        div1 = QFrame()
        div1.setFrameShape(QFrame.Shape.HLine)
        div1.setFixedHeight(1)
        div1.setStyleSheet(f"background: {C['border']}; border: none; margin: 4px 0;")
        lay.addWidget(div1)

        self.status_lbl = QLabel("\u25cf  Connecting...")
        self.status_lbl.setStyleSheet(f"color: {C['silver3']}; font-size: 11px; padding: 2px 0; background: transparent; border: none;")
        lay.addWidget(self.status_lbl)

        new_btn = Btn("+ New Conversation", primary=True)
        new_btn.setFixedHeight(38)
        new_btn.clicked.connect(self.new_session_requested.emit)
        lay.addWidget(new_btn)

        hist = QLabel("HISTORY")
        hist.setStyleSheet(f"color: {C['silver3']}; font-size: 10px; font-weight: 700; letter-spacing: 2px; padding: 10px 0 4px 2px; background: transparent; border: none;")
        lay.addWidget(hist)

        self.slist = QListWidget()
        self.slist.setStyleSheet(f"""
            QListWidget {{ background: transparent; border: none; outline: none; }}
            QListWidget::item {{
                background: transparent; color: {C['silver2']};
                border-radius: 7px; padding: 8px 10px; font-size: 12px;
                margin: 1px 0; border: 1px solid transparent;
            }}
            QListWidget::item:hover {{
                background: {C['surface3']}; color: {C['silver']};
                border-color: {C['border']};
            }}
            QListWidget::item:selected {{
                background: {C['surface3']}; color: {C['purple2']};
                border: 1px solid {C['border2']};
            }}
        """)
        self.slist.itemClicked.connect(self._on_click)
        lay.addWidget(self.slist)

        lay.addStretch()
        div2 = QFrame()
        div2.setFrameShape(QFrame.Shape.HLine)
        div2.setFixedHeight(1)
        div2.setStyleSheet(f"background: {C['border']}; border: none;")
        lay.addWidget(div2)

        gal = Btn("\u25a7  Image Gallery")
        gal.setFixedHeight(36)
        gal.clicked.connect(self._open_gallery)
        lay.addWidget(gal)

    def set_status(self, connected, text=''):
        color = C['green'] if connected else C['red']
        label = text or ('Connected' if connected else 'Disconnected')
        self.status_lbl.setText(f"\u25cf  {label}")
        self.status_lbl.setStyleSheet(f"color: {color}; font-size: 11px; padding: 2px 0; background: transparent; border: none;")

    def load_sessions(self, sessions):
        self.slist.clear()
        for s in sessions:
            t = s['title'][:28] + ('\u2026' if len(s['title']) > 28 else '')
            it = QListWidgetItem(f"  \u25c7  {t}")
            it.setData(Qt.ItemDataRole.UserRole,     s['id'])
            it.setData(Qt.ItemDataRole.UserRole + 1, s['title'])
            self.slist.addItem(it)

    def _on_click(self, item):
        self.session_selected.emit(
            item.data(Qt.ItemDataRole.UserRole),
            item.data(Qt.ItemDataRole.UserRole + 1))

    def _open_gallery(self):
        GalleryDialog(self).exec()

    def select_by_id(self, sid):
        for i in range(self.slist.count()):
            it = self.slist.item(i)
            if it.data(Qt.ItemDataRole.UserRole) == sid:
                self.slist.setCurrentItem(it)
                break


# ─────────────────────────────────────────────────────────────────────────────
#  INPUT PANEL
# ─────────────────────────────────────────────────────────────────────────────

class InputPanel(QWidget):
    send_text  = pyqtSignal(str, str)
    send_image = pyqtSignal(bytes, str)

    def __init__(self):
        super().__init__()
        self._img = None
        self._build()

    def _build(self):
        self.setStyleSheet(f"QWidget {{ background: {C['surface']}; border-top: 1px solid {C['border']}; }}")
        out = QVBoxLayout(self)
        out.setContentsMargins(20, 12, 20, 16)
        out.setSpacing(10)

        ctrl = QHBoxLayout()
        ctrl.setSpacing(8)
        ml = QLabel("Model")
        ml.setStyleSheet(f"color: {C['silver3']}; font-size: 11px; background: transparent; border: none;")
        ctrl.addWidget(ml)

        self.combo = QComboBox()
        self.combo.addItems([
            "LoRA-SD  \u2014  Text to Image",
            "VAE-GAN  \u2014  Random Generation",
            "BLIP2  \u2014  Image Captioning",
            "Gemini  \u2014  Astronomy Chat",
        ])
        self.combo.setStyleSheet(f"""
            QComboBox {{
                background: {C['surface2']}; color: {C['silver']};
                border: 1px solid {C['border']}; border-radius: 7px;
                padding: 5px 12px; font-size: 12px; min-width: 210px;
            }}
            QComboBox::drop-down {{ border: none; padding-right: 8px; }}
            QComboBox QAbstractItemView {{
                background: {C['surface2']}; color: {C['silver']};
                selection-background-color: {C['surface3']};
                border: 1px solid {C['border2']};
            }}
        """)
        ctrl.addWidget(self.combo)
        ctrl.addStretch()

        self.upload_btn = Btn("Upload Image", small=True)
        self.upload_btn.clicked.connect(self._upload)
        ctrl.addWidget(self.upload_btn)

        self.clear_btn = Btn("Clear", small=True)
        self.clear_btn.setVisible(False)
        self.clear_btn.clicked.connect(self._clear)
        ctrl.addWidget(self.clear_btn)
        out.addLayout(ctrl)

        self.preview = QLabel()
        self.preview.setVisible(False)
        self.preview.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.preview.setFixedHeight(76)
        self.preview.setStyleSheet(f"background: {C['surface2']}; border: 1px solid {C['border2']}; border-radius: 8px; padding: 4px;")
        out.addWidget(self.preview)

        row = QHBoxLayout()
        row.setSpacing(12)
        self.txt = QTextEdit()
        self.txt.setPlaceholderText("Describe a galaxy, nebula or stellar object to generate... or ask an astronomy question.")
        self.txt.setFixedHeight(78)
        self.txt.setStyleSheet(f"""
            QTextEdit {{
                background: {C['surface2']}; color: {C['silver']};
                border: 1px solid {C['border']}; border-radius: 10px;
                padding: 12px 14px; font-size: 13px;
            }}
            QTextEdit:focus {{ border-color: {C['purple_dim']}; }}
        """)
        row.addWidget(self.txt)

        send = Btn("Send", primary=True)
        send.setFixedSize(90, 78)
        send.setShortcut(QKeySequence("Ctrl+Return"))
        send.clicked.connect(self._send)
        row.addWidget(send)
        out.addLayout(row)

        hint = QLabel("Ctrl+Enter to send   \u00b7   Upload an image to caption or analyze it")
        hint.setStyleSheet(f"color: {C['silver3']}; font-size: 11px; background: transparent; border: none;")
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        out.addWidget(hint)

    def _upload(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Image", "", "Images (*.png *.jpg *.jpeg *.webp *.bmp)")
        if path:
            with open(path, 'rb') as f:
                self._img = f.read()
            pix = QPixmap(path).scaled(200, 68, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            self.preview.setPixmap(pix)
            self.preview.setVisible(True)
            self.clear_btn.setVisible(True)

    def _clear(self):
        self._img = None
        self.preview.clear()
        self.preview.setVisible(False)
        self.clear_btn.setVisible(False)

    def _send(self):
        text = self.txt.toPlainText().strip()
        if not text and not self._img:
            return
        if self._img:
            self.send_image.emit(self._img, text)
        else:
            self.send_text.emit(text, self._mode())
        self.txt.clear()

    def _mode(self):
        t = self.combo.currentText()
        if 'LoRA' in t: return 'generate_lora'
        if 'VAE'  in t: return 'generate_vae'
        if 'BLIP' in t: return 'caption'
        return 'chat'

    def get_model(self):
        t = self.combo.currentText()
        if 'LoRA' in t: return 'lora_sd'
        if 'VAE'  in t: return 'vae_gan'
        if 'BLIP' in t: return 'blip2'
        return 'gemini'


# ─────────────────────────────────────────────────────────────────────────────
#  WELCOME PAGE  — completely redesigned feature section
#  Replaces the old icon-box cards with a clean horizontal feature strip
#  and a separate model status row
# ─────────────────────────────────────────────────────────────────────────────

class WelcomePage(QWidget):
    def __init__(self):
        super().__init__()
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet(f"background: {C['void']};")
        self._canvas = StarCanvas(self)

        # Content pane — NOT a QScrollArea (that caused lag)
        # Use a plain widget. Content is designed to fit in 720px+ height.
        self._content = QWidget(self)
        self._content.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self._content.setStyleSheet("background: transparent;")
        self._build_content()

    def _build_content(self):
        lay = QVBoxLayout(self._content)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.setAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter)

        lay.addStretch(2)

        # Star icon
        ic = QLabel("\u2736")
        ic.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ic.setStyleSheet(f"color: {C['purple2']}; font-size: 44px; background: transparent;")
        lay.addWidget(ic)
        lay.addSpacing(12)

        # Title
        title = QLabel("AstroGen")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet(f"""
            color: {C['silver']}; font-size: 56px; font-weight: 800;
            letter-spacing: 8px; background: transparent;
        """)
        lay.addWidget(title)
        lay.addSpacing(10)

        # Subtitle
        sub = QLabel("AI  \u00b7  Deep Space Image Studio")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub.setStyleSheet(f"""
            color: {C['purple2']}; font-size: 13px; font-weight: 600;
            letter-spacing: 5px; background: transparent;
        """)
        lay.addWidget(sub)
        lay.addSpacing(22)

        # Description — single centered block, no extra wrapping
        desc = QLabel(
            "AstroGen is an AI-powered desktop studio for exploring the universe through generative imagery.\n"
            "Built on fine-tuned Stable Diffusion with LoRA and a custom VAE-GAN trained on 8,600+ APOD images,\n"
            "it generates astronomical imagery, captions space photos, and answers astronomy questions."
        )
        desc.setAlignment(Qt.AlignmentFlag.AlignCenter)
        desc.setWordWrap(False)      # fixed, no word-wrap for cleaner centering
        desc.setStyleSheet(f"""
            color: {C['silver2']}; font-size: 12.5px; line-height: 1.9;
            background: transparent;
        """)
        lay.addWidget(desc)
        lay.addSpacing(36)

        # ── Feature strip — horizontal list instead of icon boxes ──
        features_widget = QWidget()
        features_widget.setStyleSheet("background: transparent;")
        features_widget.setFixedWidth(900)
        fl = QHBoxLayout(features_widget)
        fl.setContentsMargins(0, 0, 0, 0)
        fl.setSpacing(0)

        features = [
            ("\u2736", "Text \u2192 Image",   "LoRA fine-tuned SD\ngenerates astronomical\nimagery from text",    True),
            ("\u25a7", "Image Analysis",       "BLIP2 captions and\nanalyzes your space\nphotographs",             False),
            ("\u25c7", "Astronomy Chat",        "Gemini-powered QA\nabout stars, galaxies\nand the cosmos",         False),
            ("\u2609", "Image Gallery",         "Browse and download\nyour generated\nastronomical artwork",        False),
        ]

        for i, (icon, label, body, accent) in enumerate(features):
            if i > 0:
                sep = QFrame()
                sep.setFrameShape(QFrame.Shape.VLine)
                sep.setFixedWidth(1)
                sep.setStyleSheet(f"background: {C['border']}; border: none; margin: 0 4px;")
                fl.addWidget(sep)

            cell = QWidget()
            cell.setStyleSheet("background: transparent;")
            cl = QVBoxLayout(cell)
            cl.setContentsMargins(28, 0, 28, 0)
            cl.setSpacing(6)
            cl.setAlignment(Qt.AlignmentFlag.AlignCenter)

            icl = QLabel(icon)
            icl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            icl.setStyleSheet(f"color: {C['purple2'] if accent else C['silver3']}; font-size: 20px; background: transparent;")
            cl.addWidget(icl)

            tl = QLabel(label)
            tl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            tl.setStyleSheet(f"color: {C['silver'] if accent else C['silver2']}; font-size: 13px; font-weight: 700; background: transparent;")
            cl.addWidget(tl)

            bl = QLabel(body)
            bl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            bl.setStyleSheet(f"color: {C['silver3']}; font-size: 11px; line-height: 1.7; background: transparent;")
            cl.addWidget(bl)
            fl.addWidget(cell, 1)

        feat_row = QHBoxLayout()
        feat_row.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        feat_row.addWidget(features_widget)
        lay.addLayout(feat_row)
        lay.addSpacing(30)

        # ── Stats strip ──
        stats_w = QWidget()
        stats_w.setFixedWidth(780)
        stats_w.setStyleSheet(f"""
            background: rgba(15, 15, 36, 0.85);
            border: 1px solid {C['border']};
            border-radius: 14px;
        """)
        sl = QHBoxLayout(stats_w)
        sl.setContentsMargins(0, 0, 0, 0)
        sl.setSpacing(0)

        for i, (val, lbl) in enumerate([
            ("8,600+", "Training Images"),
            ("3,000",  "Training Steps"),
            ("+25.6%", "CLIP Score Gain"),
            ("+70.4%", "IS Score Gain"),
        ]):
            if i > 0:
                sd = QFrame()
                sd.setFrameShape(QFrame.Shape.VLine)
                sd.setFixedWidth(1)
                sd.setStyleSheet(f"background: {C['border']}; border: none; margin: 16px 0;")
                sl.addWidget(sd)
            cell = QWidget()
            cell.setStyleSheet("background: transparent;")
            cl = QVBoxLayout(cell)
            cl.setContentsMargins(30, 20, 30, 20)
            cl.setSpacing(4)
            cl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            vl = QLabel(val)
            vl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            vl.setStyleSheet(f"color: {C['purple2']}; font-size: 22px; font-weight: 800; background: transparent;")
            ll = QLabel(lbl)
            ll.setAlignment(Qt.AlignmentFlag.AlignCenter)
            ll.setStyleSheet(f"color: {C['silver3']}; font-size: 11px; letter-spacing: 0.8px; background: transparent;")
            cl.addWidget(vl)
            cl.addWidget(ll)
            sl.addWidget(cell, 1)

        sr = QHBoxLayout()
        sr.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        sr.addWidget(stats_w)
        lay.addLayout(sr)
        lay.addStretch(2)

        # Bottom hint
        hint = QLabel("Select a session from the sidebar  \u00b7  or start a New Conversation")
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hint.setStyleSheet(f"color: {C['silver3']}; font-size: 12px; background: transparent;")
        lay.addWidget(hint)
        lay.addSpacing(20)

    def resizeEvent(self, e):
        self._canvas.setGeometry(0, 0, self.width(), self.height())
        self._content.setGeometry(0, 0, self.width(), self.height())
        super().resizeEvent(e)


# ─────────────────────────────────────────────────────────────────────────────
#  CHAT VIEW
# ─────────────────────────────────────────────────────────────────────────────

class ChatView(QWidget):
    def __init__(self):
        super().__init__()
        self._build()

    def _build(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        self.hdr = QWidget()
        self.hdr.setFixedHeight(50)
        self.hdr.setStyleSheet(f"background: {C['surface']}; border-bottom: 1px solid {C['border']};")
        hl = QHBoxLayout(self.hdr)
        hl.setContentsMargins(24, 0, 24, 0)
        self.title_lbl = QLabel("New Conversation")
        self.title_lbl.setStyleSheet(f"color: {C['silver']}; font-size: 14px; font-weight: 600;")
        hl.addWidget(self.title_lbl)
        hl.addStretch()
        lay.addWidget(self.hdr)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setStyleSheet(f"background: {C['deep']}; border: none;")

        self.msgs_w = QWidget()
        self.msgs_w.setStyleSheet(f"background: {C['deep']};")
        self.msgs_l = QVBoxLayout(self.msgs_w)
        self.msgs_l.setContentsMargins(48, 20, 48, 20)
        self.msgs_l.setSpacing(8)
        self.msgs_l.addStretch()

        self.scroll.setWidget(self.msgs_w)
        lay.addWidget(self.scroll, 1)
        self._thinking = None

    def set_title(self, t):
        self.title_lbl.setText(t)

    def clear(self):
        while self.msgs_l.count() > 1:
            item = self.msgs_l.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def add_message(self, role, content, msg_type='text', model_used=None, timestamp=None):
        b = MessageBubble(role, content, msg_type, model_used, timestamp)
        self.msgs_l.insertWidget(self.msgs_l.count() - 1, b)
        QTimer.singleShot(60, lambda: self.scroll.verticalScrollBar().setValue(
            self.scroll.verticalScrollBar().maximum()))

    def show_thinking(self):
        self._thinking = ThinkingBubble()
        self.msgs_l.insertWidget(self.msgs_l.count() - 1, self._thinking)
        QTimer.singleShot(60, lambda: self.scroll.verticalScrollBar().setValue(
            self.scroll.verticalScrollBar().maximum()))

    def hide_thinking(self):
        if self._thinking:
            self._thinking.stop()
            self._thinking.deleteLater()
            self._thinking = None


# ─────────────────────────────────────────────────────────────────────────────
#  GALLERY
# ─────────────────────────────────────────────────────────────────────────────

class GalleryDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("AstroGen - Image Gallery")
        self.setFixedSize(920, 660)
        self.setStyleSheet(f"background: {C['deep']}; color: {C['silver']};")
        self._build()
        self._load()

    def _build(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 24, 24, 24)
        lay.setSpacing(16)
        hdr = QHBoxLayout()
        t = QLabel("\u2736  Generated Images")
        t.setStyleSheet(f"color: {C['silver']}; font-size: 18px; font-weight: 700; letter-spacing: 1px;")
        hdr.addWidget(t)
        hdr.addStretch()
        cb = Btn("Close", small=True)
        cb.clicked.connect(self.close)
        hdr.addWidget(cb)
        lay.addLayout(hdr)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setStyleSheet(f"background: {C['surface']}; border: 1px solid {C['border']}; border-radius: 10px;")
        self.gw = QWidget()
        self.gw.setStyleSheet(f"background: {C['surface']};")
        self.grid = QGridLayout(self.gw)
        self.grid.setSpacing(12)
        self.grid.setContentsMargins(14, 14, 14, 14)
        self.scroll.setWidget(self.gw)
        lay.addWidget(self.scroll)

    def _load(self):
        try:
            r = requests.get(f"{API_BASE}/gallery", timeout=10)
            images = r.json()
            for idx, img in enumerate(images):
                row, col = idx // 4, idx % 4
                frame = QFrame()
                frame.setStyleSheet(f"""
                    QFrame {{ background: {C['surface2']}; border: 1px solid {C['border']}; border-radius: 8px; }}
                    QFrame:hover {{ border-color: {C['purple_dim']}; }}
                """)
                v = QVBoxLayout(frame)
                v.setContentsMargins(6, 6, 6, 6)
                v.setSpacing(5)
                lbl = QLabel()
                if img.get('thumbnail_b64'):
                    dat = base64.b64decode(img['thumbnail_b64'])
                    pix = QPixmap()
                    pix.loadFromData(dat)
                    pix = pix.scaled(180, 180, Qt.AspectRatioMode.KeepAspectRatio,
                                     Qt.TransformationMode.SmoothTransformation)
                    lbl.setPixmap(pix)
                else:
                    lbl.setText("No preview")
                    lbl.setStyleSheet(f"color: {C['silver3']};")
                lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
                v.addWidget(lbl)
                info = QLabel(f"{img.get('model_used','')}\n{(img.get('prompt') or '')[:36]}...")
                info.setStyleSheet(f"color: {C['silver3']}; font-size: 10px;")
                info.setWordWrap(True)
                v.addWidget(info)
                self.grid.addWidget(frame, row, col)
        except Exception as e:
            err = QLabel(f"Could not load gallery: {e}")
            err.setStyleSheet(f"color: {C['red']};")
            self.grid.addWidget(err, 0, 0)


# ─────────────────────────────────────────────────────────────────────────────
#  MAIN WINDOW
# ─────────────────────────────────────────────────────────────────────────────

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AstroGen  \u00b7  AI Space Image Studio")
        self.setMinimumSize(1100, 720)
        self.resize(1300, 820)
        self.setStyleSheet(GLOBAL_STYLE)
        self._sid    = None
        self._stitle = "New Conversation"
        self._workers = []
        self._build()
        self._check_backend()
        self._load_sessions()

    def _build(self):
        central = QWidget()
        self.setCentralWidget(central)
        ml = QHBoxLayout(central)
        ml.setContentsMargins(0, 0, 0, 0)
        ml.setSpacing(0)

        self.sidebar = Sidebar()
        self.sidebar.session_selected.connect(self._on_session_selected)
        self.sidebar.new_session_requested.connect(self._new_session)
        ml.addWidget(self.sidebar)

        self.stack = QStackedWidget()
        self.stack.setStyleSheet(f"background: {C['deep']};")
        ml.addWidget(self.stack, 1)

        self.welcome = WelcomePage()
        self.stack.addWidget(self.welcome)

        chat_page = QWidget()
        chat_page.setStyleSheet(f"background: {C['deep']};")
        cl = QVBoxLayout(chat_page)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(0)
        self.chat = ChatView()
        cl.addWidget(self.chat, 1)
        self.inp = InputPanel()
        self.inp.send_text.connect(self._on_send_text)
        self.inp.send_image.connect(self._on_send_image)
        cl.addWidget(self.inp)
        self.stack.addWidget(chat_page)
        self.stack.setCurrentIndex(0)

    # Backend ─────────────────────────────────────────────────────────────────

    def _check_backend(self):
        w = APIWorker('/status', 'GET')
        w.result_ready.connect(self._on_backend_ok)
        w.error_signal.connect(lambda _: self.sidebar.set_status(False, "Backend offline"))
        w.start(); self._workers.append(w)
        QTimer.singleShot(30000, self._check_backend)

    def _on_backend_ok(self, data):
        models = data.get('models', {})
        active = sum(1 for v in models.values() if v is True)
        lora_ready = models.get('lora_sd', False)
        txt = f"{active} models ready" + (" \u2014 LoRA loaded" if lora_ready else "")
        self.sidebar.set_status(True, txt)

    # Sessions ────────────────────────────────────────────────────────────────

    def _load_sessions(self):
        w = APIWorker('/sessions', 'GET')
        w.result_ready.connect(lambda d: self.sidebar.load_sessions(d))
        w.start(); self._workers.append(w)

    def _new_session(self):
        w = APIWorker('/sessions', 'POST', params={'title': 'New Conversation'})
        w.result_ready.connect(self._on_session_created)
        w.error_signal.connect(self._show_err)
        w.start(); self._workers.append(w)

    def _on_session_created(self, data):
        self._sid    = data['session_id']
        self._stitle = data['title']
        self.chat.clear()
        self.chat.set_title(data['title'])
        self.stack.setCurrentIndex(1)
        self._load_sessions()
        self.sidebar.select_by_id(data['session_id'])

    def _on_session_selected(self, sid, title):
        self._sid    = sid
        self._stitle = title
        self.chat.set_title(title)
        self.chat.clear()
        self.stack.setCurrentIndex(1)
        w = APIWorker(f'/sessions/{sid}/messages', 'GET')
        w.result_ready.connect(self._on_msgs)
        w.start(); self._workers.append(w)

    def _on_msgs(self, msgs):
        self.chat.clear()
        for m in msgs:
            self.chat.add_message(
                role=m['role'], content=m['content'],
                msg_type=m.get('msg_type', 'text'),
                model_used=m.get('model_used'),
                timestamp=m.get('created_at'))

    # Send ────────────────────────────────────────────────────────────────────

    def _ensure_session(self):
        if self._sid is None:
            try:
                r = requests.post(f"{API_BASE}/sessions",
                                  params={'title': 'New Conversation'}, timeout=5)
                d = r.json()
                self._sid    = d['session_id']
                self._stitle = d['title']
                self.chat.set_title(d['title'])
                self._load_sessions()
            except Exception:
                pass

    def _on_send_text(self, text, mode):
        self._ensure_session()
        if not self._sid:
            self._show_err("Could not create session - is backend running?")
            return
        self.stack.setCurrentIndex(1)
        self.chat.add_message('user', text)
        model = self.inp.get_model()
        if model in ('lora_sd', 'vae_gan') or 'generate' in mode:
            self._gen(text, model)
        elif model == 'blip2':
            self.chat.add_message('assistant',
                "Upload an image using the Upload Image button, then send to caption it.",
                'text', 'system')
        else:
            self._chat(text)

    def _on_send_image(self, img_bytes, question):
        self._ensure_session()
        self.stack.setCurrentIndex(1)
        self.chat.add_message('user', f"[Image] {question or 'Analyzing...'}")
        self.chat.show_thinking()
        img_b64 = base64.b64encode(img_bytes).decode()
        model = self.inp.get_model()
        if model == 'gemini':
            w = APIWorker('/chat', 'POST', {
                'message': question or "What is this astronomical image? Explain in detail.",
                'session_id': self._sid, 'image_b64': img_b64,
            })
            w.result_ready.connect(self._on_chat_res)
        else:
            w = APIWorker('/caption', 'POST', {
                'image_b64': img_b64, 'question': question or None,
                'session_id': self._sid,
            })
            w.result_ready.connect(self._on_caption_res)
        w.error_signal.connect(self._on_err)
        w.start(); self._workers.append(w)

    def _gen(self, prompt, model):
        self.chat.show_thinking()
        w = APIWorker('/generate', 'POST', {
            'prompt': prompt, 'model': model,
            'session_id': self._sid, 'num_steps': 30, 'guidance_scale': 7.5,
        })
        w.result_ready.connect(self._on_gen_res)
        w.error_signal.connect(self._on_err)
        w.start(); self._workers.append(w)

    def _chat(self, msg):
        self.chat.show_thinking()
        w = APIWorker('/chat', 'POST', {'message': msg, 'session_id': self._sid})
        w.result_ready.connect(self._on_chat_res)
        w.error_signal.connect(self._on_err)
        w.start(); self._workers.append(w)

    # Results ─────────────────────────────────────────────────────────────────

    def _on_gen_res(self, data):
        self.chat.hide_thinking()
        fp = data.get('filepath', '')
        if fp and os.path.exists(fp):
            self.chat.add_message('assistant', fp, 'image', model_used=data.get('model_used'))
            if data.get('enriched_prompt'):
                self.chat.add_message('assistant',
                    f"Prompt used:\n{data['enriched_prompt']}", 'text', 'system')
        else:
            self._show_err("Image generated but file not found. Check backend logs.")

    def _on_caption_res(self, data):
        self.chat.hide_thinking()
        self.chat.add_message('assistant', data.get('caption', 'No caption returned.'), 'text', 'blip2')

    def _on_chat_res(self, data):
        self.chat.hide_thinking()
        self.chat.add_message('assistant', data.get('response', 'No response.'), 'text', 'gemini')

    def _on_err(self, err):
        self.chat.hide_thinking()
        self.chat.add_message('assistant', f"Error: {err}", 'text', 'error')

    def _show_err(self, msg):
        self.chat.add_message('assistant', f"Error: {msg}", 'text', 'error')


# ─────────────────────────────────────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("AstroGen")
    app.setOrganizationName("AstroGen")

    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window,          QColor(C['deep']))
    palette.setColor(QPalette.ColorRole.WindowText,      QColor(C['silver']))
    palette.setColor(QPalette.ColorRole.Base,            QColor(C['surface']))
    palette.setColor(QPalette.ColorRole.AlternateBase,   QColor(C['surface2']))
    palette.setColor(QPalette.ColorRole.Text,            QColor(C['silver']))
    palette.setColor(QPalette.ColorRole.Button,          QColor(C['surface']))
    palette.setColor(QPalette.ColorRole.ButtonText,      QColor(C['silver']))
    palette.setColor(QPalette.ColorRole.Highlight,       QColor(C['purple']))
    palette.setColor(QPalette.ColorRole.HighlightedText, QColor('#ffffff'))
    app.setPalette(palette)

    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()

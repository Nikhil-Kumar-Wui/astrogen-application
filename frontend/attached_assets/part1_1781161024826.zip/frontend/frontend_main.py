"""
AstroGen — Void Cartography UI
Aesthetic: star atlas at 3am. Near-black monochrome, bone-white type, ember accent.
No blue. No gradients. Just precision and depth.
"""
import sys, os, base64, math, random, threading
from datetime import datetime
import requests

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTextEdit, QScrollArea, QFrame,
    QFileDialog, QComboBox, QStackedWidget, QListWidget,
    QListWidgetItem, QDialog, QGridLayout, QSizePolicy, QSpacerItem,
    QGraphicsOpacityEffect,
)
from PyQt6.QtCore import (
    Qt, QThread, pyqtSignal, QTimer, QPointF, QRectF, QRect, QSize,
)
from PyQt6.QtGui import (
    QFont, QPixmap, QColor, QPainter, QBrush, QLinearGradient,
    QRadialGradient, QCursor, QKeySequence, QPen, QPalette,
    QFontDatabase, QPolygonF,
)

API = "http://localhost:8000"

# ── Palette: void cartography ──────────────────────────────────────────────────
V0  = "#020203"   # deepest void
V1  = "#07070a"   # base bg
V2  = "#0c0c11"   # surface
V3  = "#111118"   # surface raised
V4  = "#181820"   # surface top
V5  = "#1f1f2a"   # border region
LN  = "#252535"   # hairline border
LN2 = "#2e2e42"   # active border
EM  = "#c8a96e"   # ember — the ONLY warm color
EM2 = "#e8c98e"   # ember light
EM3 = "#8a6a32"   # ember dim
EM_BG = "#0e0a04" # ember bg
T0  = "#f0eee8"   # bone white — primary text
T1  = "#a8a49c"   # warm mid
T2  = "#5a5850"   # dim text
T3  = "#2c2a26"   # ghost text
GR  = "#4a9468"   # go green
RD  = "#c85848"   # error red

GS = f"""
QMainWindow, QDialog {{ background:{V0}; color:{T0}; }}
QWidget {{ font-family:'Segoe UI',Tahoma,sans-serif; font-size:13px; color:{T0}; background:transparent; }}
QScrollBar:vertical {{ background:transparent; width:3px; margin:0; }}
QScrollBar::handle:vertical {{ background:{LN}; border-radius:2px; min-height:30px; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height:0; }}
QScrollBar:horizontal {{ height:3px; background:transparent; }}
QScrollBar::handle:horizontal {{ background:{LN}; border-radius:2px; }}
QComboBox QAbstractItemView {{
    background:{V4}; color:{T0}; border:1px solid {LN2};
    selection-background-color:{EM_BG}; selection-color:{EM2};
    outline:none; padding:2px;
}}
QToolTip {{ background:{V4}; color:{T0}; border:1px solid {LN}; border-radius:4px; padding:5px 9px; font-size:11px; }}
"""


# ── Worker ─────────────────────────────────────────────────────────────────────
class W(QThread):
    ok  = pyqtSignal(dict)
    err = pyqtSignal(str)
    def __init__(self, ep, method='GET', data=None, files=None, params=None):
        super().__init__()
        self.ep=ep; self.method=method; self.data=data or {}
        self.files=files; self.params=params or {}
    def run(self):
        try:
            url=f"{API}{self.ep}"
            if   self.method=='POST':
                r=(requests.post(url,files=self.files,params=self.params,timeout=300)
                   if self.files else requests.post(url,json=self.data,timeout=300))
            elif self.method=='DELETE': r=requests.delete(url,timeout=10)
            else: r=requests.get(url,params=self.params,timeout=30)
            self.ok.emit(r.json()) if r.ok else self.err.emit(f"HTTP {r.status_code}")
        except requests.ConnectionError: self.err.emit("Backend offline")
        except Exception as e: self.err.emit(str(e))


# ── Star field — rendered once, no animation (performance) ────────────────────
class StarField(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self._stars = None
        self._t = 0.0
        t = QTimer(self); t.timeout.connect(self._tick); t.start(100)

    def _tick(self):
        self._t += 0.08
        self.update()

    def resizeEvent(self, e):
        rng = random.Random(42)
        self._stars = [(rng.random(), rng.random(),
                        rng.uniform(0.2,1.6), rng.uniform(0,6.28),
                        rng.uniform(0.4,1.5)) for _ in range(200)]

    def paintEvent(self, e):
        if not self._stars: return
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        for rx, ry, sz, ph, sp in self._stars:
            a = int(20 + 140 * abs(math.sin(self._t * sp * 0.3 + ph)))
            warm = int(a * 0.15)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(QColor(240+warm, 235+warm, 220, a)))
            p.drawEllipse(QPointF(rx*w, ry*h), sz, sz)
        p.end()


# ── Ember dot (status indicator) ──────────────────────────────────────────────
class EmberDot(QWidget):
    def __init__(self, color=GR):
        super().__init__(); self.setFixedSize(10,10)
        self._c = color; self._r = 2.8; self._grow = True
        t=QTimer(self); t.timeout.connect(self._tick); t.start(70)
    def set_color(self, c): self._c = c; self.update()
    def _tick(self):
        self._r += 0.12 if self._grow else -0.12
        if self._r>4.0: self._grow=False
        elif self._r<2.0: self._grow=True
        self.update()
    def paintEvent(self, e):
        p=QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        c=QColor(self._c); g=QColor(c); g.setAlpha(35)
        p.setPen(Qt.PenStyle.NoPen); p.setBrush(g)
        p.drawEllipse(QPointF(5,5),5,5)
        p.setBrush(QBrush(c))
        p.drawEllipse(QPointF(5,5),self._r,self._r)
        p.end()


# ── Animated number ────────────────────────────────────────────────────────────
class Ticker(QLabel):
    def __init__(self, val, suf="", dec=0, size=28, delay=0):
        super().__init__()
        self._v=val; self._s=suf; self._d=dec; self._step=0; self._N=60
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setStyleSheet(f"color:{EM2};font-size:{size}px;font-weight:600;letter-spacing:-1px;")
        self._fmt(0)
        QTimer.singleShot(delay, self._go)
    def _go(self):
        t=QTimer(self); t.timeout.connect(self._tick); t.start(14); self._t=t
    def _tick(self):
        self._step=min(self._step+1,self._N)
        ease=1-(1-self._step/self._N)**3
        self._fmt(self._v*ease)
        if self._step>=self._N: self._t.stop(); self._fmt(self._v)
    def _fmt(self, v):
        self.setText(f"{v:.{self._d}f}{self._s}" if self._d else f"{int(v)}{self._s}")


# ── Reusable button ────────────────────────────────────────────────────────────
class Btn(QPushButton):
    def __init__(self, text, style='ghost', small=False):
        super().__init__(text)
        self.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        p = "4px 12px" if small else "9px 20px"
        fs = "11px" if small else "13px"
        if style=='ember':
            self.setStyleSheet(f"""
                QPushButton {{ background:{EM}; color:{V0}; border:none; border-radius:6px;
                    padding:{p}; font-size:{fs}; font-weight:700; letter-spacing:0.3px; }}
                QPushButton:hover {{ background:{EM2}; }}
                QPushButton:pressed {{ background:{EM3}; }}
                QPushButton:disabled {{ background:{V4}; color:{T3}; }}
            """)
        elif style=='outline':
            self.setStyleSheet(f"""
                QPushButton {{ background:transparent; color:{EM}; border:1px solid {EM3};
                    border-radius:6px; padding:{p}; font-size:{fs}; }}
                QPushButton:hover {{ background:{EM_BG}; border-color:{EM}; color:{EM2}; }}
            """)
        elif style=='danger':
            self.setStyleSheet(f"""
                QPushButton {{ background:transparent; color:{RD}; border:1px solid {RD}44;
                    border-radius:6px; padding:{p}; font-size:{fs}; }}
                QPushButton:hover {{ background:#120606; border-color:{RD}88; }}
            """)
        else:  # ghost
            self.setStyleSheet(f"""
                QPushButton {{ background:{V3}; color:{T1}; border:1px solid {LN};
                    border-radius:6px; padding:{p}; font-size:{fs}; }}
                QPushButton:hover {{ background:{V4}; color:{T0}; border-color:{LN2}; }}
                QPushButton:pressed {{ background:{LN}; }}
            """)

def HR():
    d=QFrame(); d.setFrameShape(QFrame.Shape.HLine)
    d.setStyleSheet(f"background:{LN};border:none;max-height:1px;"); return d


# ── Sidebar ────────────────────────────────────────────────────────────────────
class Sidebar(QWidget):
    sig_home    = pyqtSignal()
    sig_new     = pyqtSignal()
    sig_sess    = pyqtSignal(int, str)
    sig_gallery = pyqtSignal()

    def __init__(self):
        super().__init__(); self.setFixedWidth(228)
        self.setStyleSheet(f"background:{V1};border-right:1px solid {LN};")
        self._build()

    def _build(self):
        lay=QVBoxLayout(self); lay.setContentsMargins(14,20,14,16); lay.setSpacing(2)

        # wordmark
        wm=QHBoxLayout(); wm.setSpacing(0)
        dot=QLabel("◉ "); dot.setStyleSheet(f"color:{EM};font-size:15px;font-weight:900;letter-spacing:-1px;")
        name=QLabel("ASTROGEN")
        name.setStyleSheet(f"color:{T0};font-size:13px;font-weight:700;letter-spacing:3px;")
        wm.addWidget(dot); wm.addWidget(name); wm.addStretch()
        lay.addLayout(wm); lay.addSpacing(22)

        self.ovw_btn=self._navbtn("◻  Overview",True)
        self.ovw_btn.clicked.connect(self.sig_home.emit)
        lay.addWidget(self.ovw_btn); lay.addSpacing(8)

        nb=Btn("＋  New Session",'ember',small=True); nb.setFixedHeight(30)
        nb.clicked.connect(self.sig_new.emit); lay.addWidget(nb)
        lay.addSpacing(16); lay.addWidget(HR()); lay.addSpacing(10)

        sec=QLabel("SESSIONS")
        sec.setStyleSheet(f"color:{T3};font-size:9px;font-weight:700;letter-spacing:2px;padding:0 4px;")
        lay.addWidget(sec); lay.addSpacing(4)

        self.sl=QListWidget()
        self.sl.setStyleSheet(f"""
            QListWidget {{ background:transparent; border:none; outline:none; }}
            QListWidget::item {{ color:{T1}; padding:6px 10px; border-radius:5px; font-size:12px; }}
            QListWidget::item:selected, QListWidget::item:hover {{
                background:{V3}; color:{T0}; border-left:2px solid {EM};
            }}
        """)
        self.sl.itemClicked.connect(
            lambda i: self.sig_sess.emit(i.data(Qt.ItemDataRole.UserRole), i.text()))
        lay.addWidget(self.sl,1)
        lay.addWidget(HR()); lay.addSpacing(8)

        gb=self._navbtn("◫  Gallery"); gb.clicked.connect(self.sig_gallery.emit)
        lay.addWidget(gb)

    def _navbtn(self, txt, active=False):
        b=QPushButton(txt); b.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        b.setStyleSheet(f"""
            QPushButton {{
                background:{'%s'%V3 if active else 'transparent'};
                color:{'%s'%T0 if active else T1};
                border:{'1px solid %s'%LN if active else 'none'};
                border-radius:5px; padding:7px 10px; font-size:12px;
                font-weight:{'600' if active else '400'}; text-align:left;
            }}
            QPushButton:hover {{ background:{V3}; color:{T0}; }}
        """)
        return b

    def load_sessions(self, sessions):
        self.sl.clear()
        for s in sessions:
            it=QListWidgetItem(s.get('title','Session')[:32])
            it.setData(Qt.ItemDataRole.UserRole, s['id'])
            self.sl.addItem(it)


# ── Home ───────────────────────────────────────────────────────────────────────
class Home(QWidget):
    sig_start = pyqtSignal()

    def __init__(self):
        super().__init__(); self.setStyleSheet(f"background:{V0};"); self._build()

    def _build(self):
        outer=QVBoxLayout(self); outer.setContentsMargins(0,0,0,0); outer.setSpacing(0)
        scroll=QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet(f"background:{V0};border:none;")

        pg=QWidget(); pg.setStyleSheet(f"background:{V0};")
        lay=QVBoxLayout(pg); lay.setContentsMargins(56,0,56,72); lay.setSpacing(0)

        # ── Hero ──────────────────────────────────────────────────────────────
        hero=QWidget(); hero.setMinimumHeight(440); hero.setStyleSheet(f"background:{V0};")
        sf=StarField(hero); sf.setGeometry(0,0,2000,440)

        hl=QVBoxLayout(hero); hl.setContentsMargins(0,90,0,60); hl.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # coordinates badge
        badge=QLabel("RA 05h 34m · Dec +22° 01'  ✦  APOD Training Corpus")
        badge.setStyleSheet(f"""
            color:{T2}; background:{V2}; border:1px solid {LN};
            border-radius:3px; font-size:10px; font-weight:400;
            letter-spacing:1px; padding:4px 14px;
        """)
        br=QHBoxLayout(); br.addStretch(); br.addWidget(badge); br.addStretch()
        hl.addLayout(br); hl.addSpacing(28)

        # large title — split for visual weight
        t_wrap=QWidget(); t_wrap.setStyleSheet("background:transparent;")
        t_lay=QVBoxLayout(t_wrap); t_lay.setContentsMargins(0,0,0,0); t_lay.setSpacing(-6)

        t_astro=QLabel("ASTRO")
        t_astro.setAlignment(Qt.AlignmentFlag.AlignCenter)
        t_astro.setStyleSheet(f"""
            color:{T0}; font-size:88px; font-weight:800;
            letter-spacing:-4px; line-height:0.9;
        """)
        t_lay.addWidget(t_astro)

        t_gen=QLabel("GEN")
        t_gen.setAlignment(Qt.AlignmentFlag.AlignCenter)
        t_gen.setStyleSheet(f"""
            color:{EM}; font-size:88px; font-weight:800;
            letter-spacing:-4px; line-height:0.9;
        """)
        t_lay.addWidget(t_gen)
        hl.addWidget(t_wrap); hl.addSpacing(20)

        sub=QLabel("Astronomical Image Synthesis · Dual-Architecture AI Framework")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub.setStyleSheet(f"color:{T2};font-size:13px;letter-spacing:1.2px;font-weight:400;")
        hl.addWidget(sub); hl.addSpacing(36)

        # CTA
        cta_row=QHBoxLayout(); cta_row.addStretch()
        cta=Btn("BEGIN SESSION  ─────────────────────────────►",'outline')
        cta.setFixedHeight(44); cta.setFixedWidth(440)
        cta.clicked.connect(self.sig_start.emit)
        cta.setStyleSheet(f"""
            QPushButton {{
                background:transparent; color:{EM}; border:1px solid {EM3};
                border-radius:4px; padding:0 20px; font-size:12px;
                font-weight:600; letter-spacing:1px; text-align:left;
            }}
            QPushButton:hover {{
                background:{EM_BG}; border-color:{EM}; color:{EM2};
                border-right:3px solid {EM};
            }}
        """)
        cta_row.addWidget(cta); cta_row.addStretch()
        hl.addLayout(cta_row)
        lay.addWidget(hero); lay.addSpacing(8)

        # ── Metric row ────────────────────────────────────────────────────────
        mrow=QHBoxLayout(); mrow.setSpacing(1)
        mdata=[
            (8600, "+", 0, "Training Images",  "NASA APOD 1995–2026",  0),
            (9,    "",  0, "Object Classes",   "Galaxy · Nebula · …", 120),
            (31,   " yr",0,"Sky Coverage",     "Every day since 1995", 240),
            (0.31, "",  2, "CLIP Score",       "+25.6% vs baseline",   360),
        ]
        for i,(n,s,d,lbl,sub2,delay) in enumerate(mdata):
            cell=QFrame()
            cell.setStyleSheet(f"""
                QFrame {{
                    background:{V1 if i%2==0 else V2};
                    border:1px solid {LN};
                    {'border-left:none;' if i>0 else ''}
                    border-radius:{'8px 0 0 8px' if i==0 else '0 8px 8px 0' if i==3 else '0'};
                }}
            """)
            cl=QVBoxLayout(cell); cl.setContentsMargins(32,22,32,22); cl.setSpacing(3)
            cl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            cl.addWidget(Ticker(n,s,d,32,delay))
            ll=QLabel(lbl); ll.setAlignment(Qt.AlignmentFlag.AlignCenter)
            ll.setStyleSheet(f"color:{T0};font-size:12px;font-weight:600;letter-spacing:0.5px;")
            cl.addWidget(ll)
            sl=QLabel(sub2); sl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            sl.setStyleSheet(f"color:{T3};font-size:10px;")
            cl.addWidget(sl); mrow.addWidget(cell,1)
        lay.addLayout(mrow); lay.addSpacing(64)

        # ── Architecture diagram-style model section ───────────────────────
        self._section(lay,"ARCHITECTURE","Three specialized models. One unified pipeline.")
        lay.addSpacing(20)

        # Architecture flow
        flow=QFrame(); flow.setStyleSheet(f"background:{V1};border:1px solid {LN};border-radius:8px;")
        fl=QHBoxLayout(flow); fl.setContentsMargins(24,24,24,24); fl.setSpacing(0)

        models=[
            ("LoRA-SD",     "01",  "TEXT\nINPUT",   "Text → Image",
             "SD 1.5 + LoRA adapters\nSemantic prompt conditioning\n3,000 steps · 512×512",
             "CLIP 0.3078\nIS 5.47\n+25.6% baseline", GR, "complete"),
            ("VAE-GAN",     "02",  "LATENT\nSPACE",  "Synthesis",
             "Custom residual encoder\nPatchGAN discriminator\nPerceptual Astronomy Loss",
             "59/100 epochs\nG 4.40 · D 0.17\nPSNR 12.59 dB", EM, "training"),
            ("BLIP2",       "03",  "IMAGE\nINPUT",   "Captioning",
             "BLIP-2 vision-language\nFine-tuned on APOD pairs\nGemini QA fallback",
             "APOD captions\nDomain vocabulary\nPending training", T2, "pending"),
        ]
        for i,(name,num,inp,role,desc,metrics,col,status) in enumerate(models):
            if i>0:
                arr=QLabel(" → ")
                arr.setStyleSheet(f"color:{T3};font-size:20px;font-weight:200;")
                arr.setAlignment(Qt.AlignmentFlag.AlignCenter); fl.addWidget(arr)

            mc=QFrame()
            mc.setStyleSheet(f"""
                QFrame {{
                    background:{V2};
                    border:1px solid {LN2 if col==EM else LN};
                    border-top:2px solid {col};
                    border-radius:6px;
                }}
            """)
            ml=QVBoxLayout(mc); ml.setContentsMargins(18,16,18,16); ml.setSpacing(8)

            hdr=QHBoxLayout()
            idx=QLabel(num); idx.setStyleSheet(f"color:{T3};font-size:10px;font-weight:700;letter-spacing:2px;")
            nm=QLabel(name); nm.setStyleSheet(f"color:{T0};font-size:15px;font-weight:700;")
            hdr.addWidget(nm); hdr.addStretch(); hdr.addWidget(idx)
            ml.addLayout(hdr)

            rl2=QLabel(role); rl2.setStyleSheet(f"color:{col};font-size:11px;font-weight:600;letter-spacing:0.5px;")
            ml.addWidget(rl2)

            sep=QFrame(); sep.setFixedHeight(1); sep.setStyleSheet(f"background:{LN};border:none;")
            ml.addWidget(sep)

            dl=QLabel(desc); dl.setWordWrap(True)
            dl.setStyleSheet(f"color:{T1};font-size:11px;line-height:1.7;")
            ml.addWidget(dl)

            met=QLabel(metrics); met.setStyleSheet(f"color:{T2};font-size:10px;line-height:1.6;")
            met.setWordWrap(True); ml.addWidget(met)
            ml.addStretch()

            sm={"complete":(GR,"▪ OPERATIONAL"),"training":(EM,"▸ TRAINING"),"pending":(T3,"· PENDING")}
            sc,st=sm.get(status,(T3,status))
            stl=QLabel(st); stl.setStyleSheet(f"color:{sc};font-size:9px;font-weight:700;letter-spacing:2px;")
            ml.addWidget(stl)
            fl.addWidget(mc,1)
        lay.addWidget(flow); lay.addSpacing(64)

        # ── Research ──────────────────────────────────────────────────────────
        self._section(lay,"NOVEL CONTRIBUTIONS","Original research methods beyond existing literature.")
        lay.addSpacing(20)

        crow=QHBoxLayout(); crow.setSpacing(12)
        contribs=[
            ("I",  "Semantic Prompt Conditioning",
             "Astronomy ontology enrichment prior to CLIP text encoding. "
             "Structured domain knowledge injected across 9 object categories: "
             "galaxy, nebula, star, planet, sun, moon, deep-sky, aurora, comet."),
            ("II", "Perceptual Astronomy Loss",
             "Five-component composite loss engineered for astronomical imagery. "
             "VGG perceptual 0.30 · Sobel edge 0.25 · FFT frequency 0.20 · "
             "SSIM 0.15 · LPIPS 0.10. Preserves filaments and spiral arms."),
            ("III","Multi-Resolution Consistency",
             "Cross-scale CLIP consistency enforced at 64×, 128×, and 512× "
             "spatial resolutions simultaneously. Maintains structural coherence "
             "across generation scales during LoRA training phase 2."),
        ]
        for num,title2,desc2 in contribs:
            cc=QFrame()
            cc.setStyleSheet(f"""
                QFrame {{
                    background:{V2}; border:1px solid {LN}; border-radius:6px;
                }}
                QFrame:hover {{ border-color:{LN2}; }}
            """)
            cl=QVBoxLayout(cc); cl.setContentsMargins(22,22,22,22); cl.setSpacing(10)

            nw=QLabel(num); nw.setStyleSheet(f"color:{EM3};font-size:36px;font-weight:800;letter-spacing:-1px;font-style:italic;")
            cl.addWidget(nw)

            tw=QLabel(title2); tw.setWordWrap(True); tw.setStyleSheet(f"color:{T0};font-size:13px;font-weight:600;")
            cl.addWidget(tw)

            acc=QFrame(); acc.setFixedSize(24,1); acc.setStyleSheet(f"background:{EM};border:none;")
            cl.addWidget(acc)

            dw=QLabel(desc2); dw.setWordWrap(True); dw.setStyleSheet(f"color:{T1};font-size:12px;line-height:1.7;")
            cl.addWidget(dw); cl.addStretch()
            crow.addWidget(cc)
        lay.addLayout(crow)

        scroll.setWidget(pg); outer.addWidget(scroll)

    def _section(self, lay, title3, sub):
        row=QHBoxLayout()
        line=QFrame(); line.setFixedHeight(1); line.setStyleSheet(f"background:{LN};border:none;")
        row.addWidget(line,1)
        lbl=QLabel(f"  {title3}  ")
        lbl.setStyleSheet(f"color:{T3};font-size:9px;font-weight:700;letter-spacing:2px;white-space:nowrap;")
        row.addWidget(lbl)
        line2=QFrame(); line2.setFixedHeight(1); line2.setStyleSheet(f"background:{LN};border:none;")
        row.addWidget(line2,3)
        lay.addLayout(row); lay.addSpacing(4)
        if sub:
            sl=QLabel(sub); sl.setStyleSheet(f"color:{T2};font-size:12px;")
            lay.addWidget(sl); lay.addSpacing(4)


# ── Message bubble ─────────────────────────────────────────────────────────────
class Bubble(QFrame):
    def __init__(self, role, content, mtype='text', model=None, ts=None):
        super().__init__()
        is_u=role=='user'
        self.setStyleSheet(f"""
            QFrame {{
                background:{V2 if is_u else V1};
                border:1px solid {LN2 if is_u else LN};
                border-left:3px solid {EM if is_u else LN};
                border-radius:6px; margin:1px 0;
            }}
        """)
        l=QVBoxLayout(self); l.setContentsMargins(16,12,16,12); l.setSpacing(6)

        hr=QHBoxLayout(); hr.setSpacing(8)
        rl=QLabel("YOU" if is_u else "ASTROGEN")
        rl.setStyleSheet(f"color:{EM if is_u else T2};font-size:10px;font-weight:700;letter-spacing:1.5px;")
        hr.addWidget(rl)
        if model and not is_u:
            mb=QLabel(f" {model.upper()} ")
            mb.setStyleSheet(f"color:{T3};background:{V3};border:1px solid {LN};border-radius:3px;font-size:9px;letter-spacing:1px;padding:1px 4px;")
            hr.addWidget(mb)
        hr.addStretch()
        if ts:
            try: tl=QLabel(datetime.fromisoformat(ts).strftime('%H:%M')); tl.setStyleSheet(f"color:{T3};font-size:10px;"); hr.addWidget(tl)
            except: pass
        l.addLayout(hr)

        if mtype=='image':
            il=QLabel()
            if os.path.exists(content):
                pix=QPixmap(content).scaled(480,480,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)
                il.setPixmap(pix); il.setStyleSheet(f"border:1px solid {LN};border-radius:4px;")
            else: il.setText("[Image file not found]")
            il.setAlignment(Qt.AlignmentFlag.AlignLeft); l.addWidget(il)
            sv=Btn("↓  Save",'ghost',small=True); sv.clicked.connect(lambda:self._save(content))
            l.addWidget(sv,alignment=Qt.AlignmentFlag.AlignLeft)
        else:
            tx=QLabel(content); tx.setWordWrap(True)
            tx.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            tx.setStyleSheet(f"color:{T0};font-size:13px;line-height:1.65;")
            l.addWidget(tx)

    def _save(self, fp):
        d,_=QFileDialog.getSaveFileName(self,"Save","","PNG (*.png);;JPEG (*.jpg)")
        if d:
            import shutil; shutil.copy2(fp,d)


class ThinkBubble(QFrame):
    def __init__(self):
        super().__init__()
        self.setStyleSheet(f"QFrame{{background:{V1};border:1px solid {LN};border-left:3px solid {LN};border-radius:6px;margin:1px 0;}}")
        l=QHBoxLayout(self); l.setContentsMargins(16,12,16,12)
        self._lbl=QLabel("ASTROGEN  ·  ·  ·"); self._lbl.setStyleSheet(f"color:{T2};font-size:11px;letter-spacing:2px;")
        l.addWidget(self._lbl); l.addStretch()
        self._s=0; t=QTimer(self); t.timeout.connect(self._tick); t.start(500); self._timer=t
    def _tick(self):
        self._s=(self._s+1)%4
        dots="·  "*self._s + " "*(3-self._s)
        self._lbl.setText(f"ASTROGEN  {dots}")
    def stop(self): self._timer.stop()


# ── Chat view ──────────────────────────────────────────────────────────────────
class ChatView(QWidget):
    def __init__(self):
        super().__init__(); self.setStyleSheet(f"background:{V0};"); self._think=None; self._build()

    def _build(self):
        l=QVBoxLayout(self); l.setContentsMargins(0,0,0,0); l.setSpacing(0)
        self.hdr=QWidget(); self.hdr.setFixedHeight(50)
        self.hdr.setStyleSheet(f"background:{V1};border-bottom:1px solid {LN};")
        hl=QHBoxLayout(self.hdr); hl.setContentsMargins(26,0,26,0)
        self.ttl=QLabel("New Session"); self.ttl.setStyleSheet(f"color:{T0};font-size:13px;font-weight:600;letter-spacing:0.5px;")
        hl.addWidget(self.ttl); hl.addStretch()
        self._dot=EmberDot(RD); self._stxt=QLabel("Connecting"); self._stxt.setStyleSheet(f"color:{T3};font-size:11px;letter-spacing:0.5px;")
        hl.addWidget(self._dot); hl.addSpacing(6); hl.addWidget(self._stxt)
        l.addWidget(self.hdr)

        self.scroll=QScrollArea(); self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setStyleSheet(f"background:{V0};border:none;")
        self.mw=QWidget(); self.mw.setStyleSheet(f"background:{V0};")
        self.ml=QVBoxLayout(self.mw); self.ml.setContentsMargins(72,24,72,24); self.ml.setSpacing(6)
        self.ml.addStretch()
        self.scroll.setWidget(self.mw); l.addWidget(self.scroll,1)

    def set_title(self,t): self.ttl.setText(t)
    def set_status(self,ok,msg=""):
        self._dot.set_color(GR if ok else RD)
        self._stxt.setText(msg or("CONNECTED" if ok else "OFFLINE"))

    def clear(self):
        while self.ml.count()>1:
            it=self.ml.takeAt(0)
            if it.widget(): it.widget().deleteLater()

    def add(self,role,content,mtype='text',model=None,ts=None):
        self.ml.insertWidget(self.ml.count()-1,Bubble(role,content,mtype,model,ts))
        QTimer.singleShot(40,lambda:self.scroll.verticalScrollBar().setValue(self.scroll.verticalScrollBar().maximum()))

    def show_think(self):
        self._think=ThinkBubble(); self.ml.insertWidget(self.ml.count()-1,self._think)
        QTimer.singleShot(40,lambda:self.scroll.verticalScrollBar().setValue(self.scroll.verticalScrollBar().maximum()))

    def hide_think(self):
        if self._think: self._think.stop(); self._think.deleteLater(); self._think=None

    def show_empty(self):
        self.clear()
        w=QLabel("No session selected.  Click ＋ New Session to begin.")
        w.setAlignment(Qt.AlignmentFlag.AlignCenter)
        w.setStyleSheet(f"color:{T3};font-size:13px;padding:80px;letter-spacing:0.5px;")
        self.ml.insertWidget(self.ml.count()-1,w)


# ── Input panel ────────────────────────────────────────────────────────────────
class InputPanel(QWidget):
    sig_text  = pyqtSignal(str,str)
    sig_image = pyqtSignal(bytes,str)

    def __init__(self):
        super().__init__(); self._img=None
        self.setStyleSheet(f"background:{V1};border-top:1px solid {LN};")
        self._build()

    def _build(self):
        l=QVBoxLayout(self); l.setContentsMargins(72,10,72,14); l.setSpacing(8)

        ctrl=QHBoxLayout(); ctrl.setSpacing(10)
        ml=QLabel("MODEL"); ml.setStyleSheet(f"color:{T3};font-size:9px;font-weight:700;letter-spacing:2px;")
        ctrl.addWidget(ml)
        self.combo=QComboBox()
        self.combo.addItems(["LoRA-SD  ·  Text → Image","VAE-GAN  ·  Synthesis","BLIP2  ·  Captioning","Gemini  ·  Q & A"])
        self.combo.setStyleSheet(f"""
            QComboBox {{
                background:{V3};color:{T0};border:1px solid {LN};
                border-radius:5px;padding:5px 10px;font-size:12px;min-width:200px;
            }}
            QComboBox::drop-down{{border:none;padding-right:8px;}}
            QComboBox:hover{{border-color:{LN2};}}
        """)
        ctrl.addWidget(self.combo); ctrl.addStretch()
        self.ubtn=Btn("↑ Upload",'ghost',small=True); self.ubtn.clicked.connect(self._upload); ctrl.addWidget(self.ubtn)
        self.xbtn=Btn("✕",'ghost',small=True); self.xbtn.setVisible(False); self.xbtn.clicked.connect(self._clr); ctrl.addWidget(self.xbtn)
        l.addLayout(ctrl)

        self.prev=QLabel(); self.prev.setVisible(False)
        self.prev.setStyleSheet(f"background:{V3};border:1px solid {LN};border-radius:4px;padding:3px;")
        self.prev.setFixedHeight(72); l.addWidget(self.prev)

        row=QHBoxLayout(); row.setSpacing(10)
        self.inp=QTextEdit()
        self.inp.setPlaceholderText("Describe a space image · Upload one to caption · Ask anything about astronomy")
        self.inp.setFixedHeight(76)
        self.inp.setStyleSheet(f"""
            QTextEdit {{
                background:{V2};color:{T0};border:1px solid {LN};
                border-radius:6px;padding:10px 14px;font-size:13px;line-height:1.5;
            }}
            QTextEdit:focus{{border-color:{EM3};}}
        """)
        row.addWidget(self.inp)
        sb=Btn("SEND",'ember'); sb.setFixedSize(80,76)
        sb.clicked.connect(self._send); sb.setShortcut(QKeySequence("Ctrl+Return"))
        row.addWidget(sb); l.addLayout(row)

        ht=QLabel("Ctrl+Enter to send  ·  Upload image for captioning or analysis")
        ht.setStyleSheet(f"color:{T3};font-size:10px;letter-spacing:0.5px;"); ht.setAlignment(Qt.AlignmentFlag.AlignCenter)
        l.addWidget(ht)

    def _upload(self):
        p,_=QFileDialog.getOpenFileName(self,"Select Image","","Images (*.png *.jpg *.jpeg *.webp)")
        if not p: return
        with open(p,'rb') as f: self._img=f.read()
        pix=QPixmap(p).scaled(200,66,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)
        self.prev.setPixmap(pix); self.prev.setVisible(True); self.xbtn.setVisible(True)

    def _clr(self): self._img=None; self.prev.clear(); self.prev.setVisible(False); self.xbtn.setVisible(False)

    def _send(self):
        text=self.inp.toPlainText().strip()
        if not text and not self._img: return
        ct=self.combo.currentText()
        if self._img: self.sig_image.emit(self._img,text)
        else:
            mode='generate' if('LoRA'in ct or'GAN'in ct) else 'caption' if'BLIP2'in ct else 'chat'
            self.sig_text.emit(text,mode)
        self.inp.clear()

    def get_model(self):
        t=self.combo.currentText()
        if'LoRA'in t:return'lora_sd'
        if'GAN'in t:return'vae_gan'
        if'BLIP2'in t:return'blip2'
        return'gemini'


# ── Gallery ────────────────────────────────────────────────────────────────────
class Gallery(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent); self.setWindowTitle("Gallery"); self.setMinimumSize(900,660)
        self.setStyleSheet(f"background:{V0};color:{T0};"); self._build(); self._load()

    def _build(self):
        l=QVBoxLayout(self); l.setContentsMargins(28,28,28,28); l.setSpacing(16)
        h=QHBoxLayout()
        t=QLabel("GENERATED IMAGES"); t.setStyleSheet(f"color:{T0};font-size:11px;font-weight:700;letter-spacing:3px;")
        h.addWidget(t); h.addStretch()
        cb=Btn("Close",'ghost',small=True); cb.clicked.connect(self.close); h.addWidget(cb)
        l.addLayout(h); l.addWidget(HR())
        scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setStyleSheet(f"background:{V0};border:none;")
        self.gw=QWidget(); self.gw.setStyleSheet(f"background:{V0};")
        self.gl=QGridLayout(self.gw); self.gl.setSpacing(8)
        scroll.setWidget(self.gw); l.addWidget(scroll)

    def _load(self):
        try:
            r=requests.get(f"{API}/gallery",timeout=5)
            imgs=r.json().get('images',[]) if r.ok else []
            for i,img in enumerate(imgs):
                fp=img.get('filepath','')
                if not fp or not os.path.exists(fp): continue
                fr=QFrame(); fr.setStyleSheet(f"QFrame{{background:{V2};border:1px solid {LN};border-radius:5px;}}")
                fl=QVBoxLayout(fr); fl.setContentsMargins(6,6,6,6); fl.setSpacing(4)
                pl=QLabel()
                pix=QPixmap(fp).scaled(195,195,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)
                pl.setPixmap(pix); pl.setAlignment(Qt.AlignmentFlag.AlignCenter); fl.addWidget(pl)
                p2=img.get('prompt','')[:40]
                if p2: tl=QLabel(p2+('…' if len(img.get('prompt',''))>40 else '')); tl.setStyleSheet(f"color:{T3};font-size:9px;"); fl.addWidget(tl)
                self.gl.addWidget(fr,i//4,i%4)
        except:
            el=QLabel("Backend offline"); el.setAlignment(Qt.AlignmentFlag.AlignCenter)
            el.setStyleSheet(f"color:{T3};font-size:12px;padding:40px;"); self.gl.addWidget(el,0,0)


# ── Main window ────────────────────────────────────────────────────────────────
class App(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("AstroGen"); self.setMinimumSize(1160,760)
        self.setStyleSheet(GS); self._sid=None; self._ws=[]
        self._build(); self._ping()

    def _build(self):
        cw=QWidget(); cw.setStyleSheet(f"background:{V0};"); self.setCentralWidget(cw)
        row=QHBoxLayout(cw); row.setContentsMargins(0,0,0,0); row.setSpacing(0)

        self.bar=Sidebar()
        self.bar.sig_home.connect(self._home)
        self.bar.sig_new.connect(self._new)
        self.bar.sig_sess.connect(self._load_sess)
        self.bar.sig_gallery.connect(lambda:Gallery(self).exec())
        row.addWidget(self.bar)

        rw=QWidget(); rw.setStyleSheet(f"background:{V0};")
        rl=QVBoxLayout(rw); rl.setContentsMargins(0,0,0,0); rl.setSpacing(0)
        self.stk=QStackedWidget(); self.stk.setStyleSheet(f"background:{V0};")

        self.home_pg=Home(); self.home_pg.sig_start.connect(self._new)
        self.stk.addWidget(self.home_pg)  # 0

        cc=QWidget(); cc.setStyleSheet(f"background:{V0};")
        cl=QVBoxLayout(cc); cl.setContentsMargins(0,0,0,0); cl.setSpacing(0)
        self.cv=ChatView(); cl.addWidget(self.cv,1)
        self.ip=InputPanel(); self.ip.sig_text.connect(self._send_text); self.ip.sig_image.connect(self._send_img)
        cl.addWidget(self.ip); self.stk.addWidget(cc)  # 1

        rl.addWidget(self.stk,1); row.addWidget(rw,1)
        self._load_sessions(); self._home()

    def _ping(self):
        def _do():
            try: ok=requests.get(f"{API}/status",timeout=3).ok
            except: ok=False
            self.cv.set_status(ok)
        threading.Thread(target=_do,daemon=True).start()
        QTimer.singleShot(6000,self._ping)

    def _home(self): self.stk.setCurrentIndex(0); self._sid=None
    def _new(self):
        w=W('/sessions','POST',params={'title':'New Session'})
        w.ok.connect(lambda d:(setattr(self,'_sid',d.get('id')), self.cv.set_title(d.get('title','Session')), self.cv.clear(), self.stk.setCurrentIndex(1), self._load_sessions()))
        w.err.connect(lambda _:(self.stk.setCurrentIndex(1),self.cv.show_empty(),self.cv.set_status(False)))
        w.start(); self._ws.append(w)

    def _load_sess(self,sid,title):
        self._sid=sid; self.cv.set_title(title); self.cv.clear(); self.stk.setCurrentIndex(1)
        w=W(f'/sessions/{sid}/messages')
        w.ok.connect(lambda d:[self.cv.add(m.get('role','assistant'),m.get('content',''),m.get('message_type','text'),m.get('model_used'),m.get('timestamp')) for m in d.get('messages',[])])
        w.err.connect(lambda _:None); w.start(); self._ws.append(w)

    def _load_sessions(self):
        w=W('/sessions'); w.ok.connect(lambda d:self.bar.load_sessions(d.get('sessions',[])))
        w.err.connect(lambda _:None); w.start(); self._ws.append(w)

    def _send_text(self,text,mode):
        if not self._sid: self._new(); QTimer.singleShot(900,lambda:self._do(text,mode)); return
        self._do(text,mode)

    def _do(self,text,mode):
        if not self._sid: return
        self.stk.setCurrentIndex(1); self.cv.add('user',text)
        m=self.ip.get_model()
        if m in('lora_sd','vae_gan') or mode=='generate': self._gen(text,m)
        elif m=='blip2': self.cv.add('assistant','Please upload an image using ↑ Upload, then send.','text','system')
        else: self._chat(text)

    def _send_img(self,ib,q):
        self.stk.setCurrentIndex(1); self.cv.add('user',f"[Image] {q or 'Analyze this image'}")
        self.cv.show_think(); b64=base64.b64encode(ib).decode()
        m=self.ip.get_model()
        if m=='gemini':
            w=W('/chat','POST',{'message':q or"Describe this astronomical image",'session_id':self._sid,'image_b64':b64})
            w.ok.connect(self._on_chat)
        else:
            w=W('/caption','POST',{'image_b64':b64,'question':q or None,'session_id':self._sid})
            w.ok.connect(self._on_cap)
        w.err.connect(self._on_err); w.start(); self._ws.append(w)

    def _gen(self,p,m):
        self.cv.show_think()
        w=W('/generate','POST',{'prompt':p,'model':m,'session_id':self._sid,'num_steps':30,'guidance_scale':7.5})
        w.ok.connect(self._on_gen); w.err.connect(self._on_err); w.start(); self._ws.append(w)

    def _chat(self,msg):
        self.cv.show_think()
        w=W('/chat','POST',{'message':msg,'session_id':self._sid})
        w.ok.connect(self._on_chat); w.err.connect(self._on_err); w.start(); self._ws.append(w)

    def _on_gen(self,d):
        self.cv.hide_think(); fp=d.get('filepath','')
        if fp and os.path.exists(fp):
            self.cv.add('assistant',fp,'image',d.get('model_used'))
            ep=d.get('enriched_prompt','')
            if ep: self.cv.add('assistant',f"Enriched: {ep}",'text','system')
        else: self.cv.add('assistant','Image generated but file not found. Check backend logs.','text','error')

    def _on_cap(self,d): self.cv.hide_think(); self.cv.add('assistant',d.get('caption','No caption.'),'text','blip2')
    def _on_chat(self,d): self.cv.hide_think(); self.cv.add('assistant',d.get('response','No response.'),'text','gemini')
    def _on_err(self,e): self.cv.hide_think(); self.cv.add('assistant',f"Error: {e}",'text','error')


def main():
    app=QApplication(sys.argv)
    app.setApplicationName("AstroGen")
    p=QPalette()
    for role,c in [(QPalette.ColorRole.Window,V0),(QPalette.ColorRole.WindowText,T0),
                   (QPalette.ColorRole.Base,V2),(QPalette.ColorRole.Text,T0),
                   (QPalette.ColorRole.Button,V3),(QPalette.ColorRole.ButtonText,T0),
                   (QPalette.ColorRole.Highlight,EM),(QPalette.ColorRole.HighlightedText,V0)]:
        p.setColor(role,QColor(c))
    app.setPalette(p)
    w=App(); w.show(); sys.exit(app.exec())

if __name__=="__main__":
    main()

import os
from PIL import Image, ImageDraw

def create_logo():
    # Create a 256x256 image with transparent background
    size = 256
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Draw a deep space circular background with purple/indigo gradient
    # We can do this by drawing concentric circles
    for r in range(120, 0, -1):
        alpha = int(255 * (r / 120))
        # Interpolate between deep violet (#140f30) and bright violet (#7c6af0)
        ratio = r / 120.0
        red = int(20 + ratio * 104)
        green = int(15 + ratio * 91)
        blue = int(48 + ratio * 192)
        
        draw.ellipse(
            [(size//2 - r, size//2 - r), (size//2 + r, size//2 + r)],
            fill=(red, green, blue, 255)
        )
        
    # Draw a glowing yellow/white star in the center
    # Center coordinates
    cx, cy = size // 2, size // 2
    
    # Core glow
    for r in range(35, 0, -1):
        alpha = int(150 * (1.0 - (r / 35.0)))
        draw.ellipse(
            [(cx - r, cy - r), (cx + r, cy + r)],
            fill=(255, 255, 255, alpha)
        )
        
    # Draw cross lines for the shining star effect
    # Horizontal line
    draw.polygon(
        [(cx - 70, cy), (cx, cy - 8), (cx + 70, cy), (cx, cy + 8)],
        fill=(255, 255, 255, 255)
    )
    # Vertical line
    draw.polygon(
        [(cx, cy - 70), (cx - 8, cy), (cx, cy + 70), (cx + 8, cy)],
        fill=(255, 255, 255, 255)
    )
    
    # Outer diamond highlight
    draw.polygon(
        [(cx - 30, cy), (cx, cy - 30), (cx + 30, cy), (cx, cy + 30)],
        fill=(220, 210, 255, 180)
    )
    
    # Save the generated image
    output_dir = os.path.dirname(__file__)
    output_path = os.path.join(output_dir, "logo.png")
    img.save(output_path, "PNG")
    print(f"Space logo generated successfully at {output_path}!")

if __name__ == "__main__":
    create_logo()

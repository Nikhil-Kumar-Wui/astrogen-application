@echo off
chcp 65001 >nul
set PYTHONIOENCODING=utf-8
set HF_HUB_DOWNLOAD_TIMEOUT=120
title AstroGen Setup and Launcher
cd /d "%~dp0"

echo ===================================================
echo   AstroGen Orbit System Initialization
echo ===================================================

if not exist ".venv\Scripts\python.exe" (
    echo [System] Virtual environment not found. Creating .venv...
    python -m venv .venv
)

echo [System] Checking Python dependencies...
.venv\Scripts\python.exe -c "import torch, diffusers, safetensors, PyQt6.QtWebEngineWidgets, requests, fastapi, uvicorn" >nul 2>&1
if errorlevel 1 (
    echo [System] Some dependencies are missing. Installing requirements...
    echo [System] Downloading torch, diffusers, PyQtWebEngine and other tools. Please wait...
    .venv\Scripts\python.exe -m pip install --upgrade pip
    .venv\Scripts\python.exe -m pip install -r requirements.txt
) else (
    echo [System] Python dependencies are ready.
)

if not exist "models\lora"    mkdir models\lora
if not exist "models\vae_gan" mkdir models\vae_gan
if not exist "models\blip2"   mkdir models\blip2
if not exist "data\generated" mkdir data\generated
if not exist ".env" echo GEMINI_API_KEY=> .env

echo [System] Checking React frontend dependencies...
if not exist "frontend_web\node_modules" (
    echo [System] node_modules not found. Installing npm packages for Vite/React...
    cd frontend_web
    call npm install
    cd ..
) else (
    echo [System] React dependencies are ready.
)

echo [System] Launching backend server on port 8001...
start "" /B .venv\Scripts\python.exe backend\main.py > backend_log.txt 2>&1

echo [System] Launching Vite React dev server on port 5173...
cd frontend_web
start "" /B npm run dev > dev_server_log.txt 2>&1
cd ..

echo [System] Initializing native Desktop window...
.venv\Scripts\python.exe frontend\launcher.py

echo [System] AstroGen session ended. Cleaning up...
taskkill /F /IM python.exe /FI "WINDOWTITLE eq AstroGen Setup and Launcher" >nul 2>&1

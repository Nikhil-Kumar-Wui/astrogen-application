/**
 * AstroGen backend API client.
 * IMPORTANT: This file mirrors the original `frontend_web/src/api.js` exactly.
 * Backend contracts, endpoints, and request/response shapes must NOT change.
 */
const BASE = "http://localhost:8001";

async function req(path: string, opts: RequestInit = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...opts,
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || `HTTP ${res.status}`);
  }
  return res.json();
}

export type Session = { id: string; title: string; created_at?: string };
export type Message = {
  id: string | number;
  role: "user" | "assistant";
  content: string;
  msg_type?: "text" | "image";
  model_used?: string;
  prompt?: string;
  timestamp?: string;
};
export type GalleryItem = {
  id?: string | number;
  filepath: string;
  prompt?: string;
  model?: string;
  thumbnail_b64?: string;
};

export const api = {
  getStatus: () => req("/status"),
  getSessions: (): Promise<Session[]> => req("/sessions"),
  createSession: (title: string): Promise<{ session_id: string }> =>
    req(`/sessions?title=${encodeURIComponent(title)}`, { method: "POST" }),
  deleteSession: (id: string) => req(`/sessions/${id}`, { method: "DELETE" }),
  getMessages: (id: string): Promise<Message[]> => req(`/sessions/${id}/messages`),
  generate: (body: { prompt: string; model: string; session_id: string }) =>
    req("/generate", { method: "POST", body: JSON.stringify(body) }),
  chat: (body: { message: string; session_id: string; image_b64?: string | null }) =>
    req("/chat", { method: "POST", body: JSON.stringify(body) }),
  caption: (body: { image_b64: string; question?: string | null; session_id: string }) =>
    req("/caption", { method: "POST", body: JSON.stringify(body) }),
  getGallery: (n = 60): Promise<GalleryItem[]> => req(`/gallery?limit=${n}`),
};

/** Convert a local file path returned by the backend into a URL the browser can load */
export function imageUrl(filepath?: string | null): string | null {
  if (!filepath) return null;
  if (filepath.startsWith("data:")) return filepath;
  const filename = filepath.replace(/\\/g, "/").split("/").pop();
  return `${BASE}/generated/${filename}`;
}

export const API_BASE = BASE;

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { api, type Message, type Session } from "@/lib/api";
import ChatSidebar from "@/components/astro/ChatSidebar";
import MessageBubble from "@/components/astro/MessageBubble";
import InputPanel, { type ModelKey } from "@/components/astro/InputPanel";
import LoadingPanel from "@/components/astro/LoadingPanel";
import GalleryModal from "@/components/astro/GalleryModal";
import ImagePreview from "@/components/astro/ImagePreview";
import { Radio, Telescope } from "lucide-react";

export const Route = createFileRoute("/chat")({ component: ChatPage });

const EXAMPLE_PROMPTS = [
  "Ultra-realistic Andromeda galaxy in deep space",
  "A black hole accretion disk near a dying red supergiant",
  "NASA telescope view of the Orion Nebula, photorealistic",
  "Spiral arms of the Whirlpool galaxy with stellar dust",
];

function ChatPage() {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingLabel, setLoadingLabel] = useState("");
  const [galleryOpen, setGalleryOpen] = useState(false);
  const [preview, setPreview] = useState<{ url: string; prompt?: string } | null>(null);
  const [prefill, setPrefill] = useState<{ text: string; model: ModelKey } | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadSessions();
  }, []);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  async function loadSessions() {
    try {
      const data = await api.getSessions();
      setSessions(data);
    } catch (e) {
      console.error(e);
    }
  }

  async function selectSession(id: string) {
    setActiveId(id);
    try {
      setMessages(await api.getMessages(id));
    } catch (e) {
      toast.error("Could not load session");
    }
  }

  async function createSession() {
    try {
      const name = `Session · ${new Date().toLocaleString([], {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      })}`;
      const res = await api.createSession(name);
      await loadSessions();
      setActiveId(res.session_id);
      setMessages([]);
      toast.success("New session started");
    } catch {
      toast.error("Backend offline — could not create session");
    }
  }

  async function deleteSession(id: string) {
    try {
      await api.deleteSession(id);
      if (activeId === id) {
        setActiveId(null);
        setMessages([]);
      }
      await loadSessions();
      toast.success("Session removed");
    } catch {
      toast.error("Failed to delete session");
    }
  }

  async function handleSend({
    text,
    model,
    imageB64,
  }: {
    text: string;
    model: ModelKey;
    imageB64: string | null;
  }) {
    let sid = activeId;
    if (!sid) {
      try {
        const name = text ? text.slice(0, 28) + (text.length > 28 ? "…" : "") : "New Session";
        const res = await api.createSession(name);
        sid = res.session_id;
        setActiveId(sid);
        await loadSessions();
      } catch {
        toast.error("Could not start a session");
        return;
      }
    }

    setLoading(true);
    if (model === "lora_sd") setLoadingLabel("Guiding Stable Diffusion UNet denoising…");
    else if (model === "vae_gan") setLoadingLabel("Sampling latent space via VAE-GAN…");
    else if (model === "blip2") setLoadingLabel("BLIP-2 reading image features…");
    else setLoadingLabel("Querying Gemini orbital mainframe…");

    // Optimistic user message
    if (text || imageB64) {
      setMessages((m) => [
        ...m,
        {
          id: `tmp-${Date.now()}`,
          role: "user",
          content: text || "(image attached)",
          msg_type: "text",
          timestamp: new Date().toISOString(),
        },
      ]);
    }

    try {
      if (model === "lora_sd" || model === "vae_gan") {
        await api.generate({
          prompt: text || "Deep space cosmic nebula",
          model,
          session_id: sid,
        });
      } else if (model === "blip2") {
        if (!imageB64) {
          toast.error("BLIP-2 needs an image. Attach one first.");
          setLoading(false);
          return;
        }
        await api.caption({ image_b64: imageB64, question: text || null, session_id: sid });
      } else {
        await api.chat({ message: text, session_id: sid, image_b64: imageB64 || null });
      }
      const msgs = await api.getMessages(sid);
      setMessages(msgs);
      toast.success("Response received");
    } catch (e: any) {
      toast.error(`Transmission error: ${e.message || "unknown"}`);
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: "assistant",
          content: `Transmission Error: ${e.message || "unknown"}`,
          msg_type: "text",
          model_used: model,
          timestamp: new Date().toISOString(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  function handleRegenerate(msg: Message) {
    const text = msg.prompt || msg.content || "";
    const model = (msg.model_used as ModelKey) || "lora_sd";
    setPrefill({ text, model });
    handleSend({ text, model, imageB64: null });
  }

  const active = sessions.find((s) => s.id === activeId);

  return (
    <div className="h-[calc(100dvh-3.5rem)] flex">
      <ChatSidebar
        sessions={sessions}
        activeId={activeId}
        onSelect={selectSession}
        onCreate={createSession}
        onDelete={deleteSession}
        onOpenGallery={() => setGalleryOpen(true)}
      />

      <div className="flex-1 flex flex-col min-w-0">
        <div className="h-12 px-5 flex items-center gap-3 border-b border-border/50 glass">
          <Radio className="size-4 text-primary" />
          <span className="font-display text-[14px] font-medium truncate">
            {active?.title || "Mission Control"}
          </span>
          <span className="ml-auto font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            {messages.length} transmissions
          </span>
        </div>

        <div className="flex-1 overflow-y-auto">
          <div className="mx-auto max-w-[860px] px-6 py-6 space-y-5">
            {messages.length === 0 && !loading && (
              <div className="text-center py-12">
                <div className="inline-flex size-14 rounded-2xl glass items-center justify-center mb-4 text-primary">
                  <Telescope className="size-7" />
                </div>
                <h2 className="font-display text-2xl font-semibold mb-2">
                  {active ? "Channel open" : "Begin a new mission"}
                </h2>
                <p className="text-[14px] text-muted-foreground max-w-md mx-auto">
                  Describe an astronomical scene or upload an image. AstroGen will route your
                  request to the right model.
                </p>
                <div className="mt-8 max-w-2xl mx-auto grid sm:grid-cols-2 gap-2">
                  {EXAMPLE_PROMPTS.map((p) => (
                    <button
                      key={p}
                      onClick={() =>
                        handleSend({ text: p, model: "lora_sd", imageB64: null })
                      }
                      className="text-left p-3 rounded-lg glass border border-border/50 hover:border-primary/40 transition group"
                    >
                      <div className="text-[10px] font-mono uppercase tracking-wider text-primary mb-1">
                        Example
                      </div>
                      <div className="text-[13px] text-foreground leading-snug">{p}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((m) => (
              <MessageBubble
                key={m.id}
                message={m}
                onPreview={(url, prompt) => setPreview({ url, prompt })}
                onRegenerate={handleRegenerate}
              />
            ))}

            <LoadingPanel active={loading} label={loadingLabel} />
            <div ref={endRef} />
          </div>
        </div>

        <div className="px-6 pb-5 pt-2">
          <div className="mx-auto max-w-[860px]">
            <InputPanel
              onSend={handleSend}
              isLoading={loading}
              initialText={prefill?.text}
              initialModel={prefill?.model}
            />
          </div>
        </div>
      </div>

      <GalleryModal
        open={galleryOpen}
        onClose={() => setGalleryOpen(false)}
        onPreview={(url, prompt) => {
          setGalleryOpen(false);
          setPreview({ url, prompt });
        }}
      />
      <ImagePreview
        url={preview?.url || null}
        prompt={preview?.prompt}
        onClose={() => setPreview(null)}
      />
    </div>
  );
}

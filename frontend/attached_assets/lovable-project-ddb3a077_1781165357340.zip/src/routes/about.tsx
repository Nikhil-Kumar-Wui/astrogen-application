import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import Footer from "@/components/astro/home/Footer";

export const Route = createFileRoute("/about")({ component: About });

function About() {
  return (
    <main>
      <section className="px-6 pt-16 pb-12">
        <div className="mx-auto max-w-3xl">
          <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full border border-border bg-secondary/50 text-[10.5px] font-mono uppercase tracking-[0.18em] text-muted-foreground mb-4">
            <span className="size-1 rounded-full bg-accent" />
            About the Project
          </div>
          <h1 className="font-display text-4xl md:text-5xl font-semibold tracking-tight mb-6">
            Built for astronomical imagery, not generic photos.
          </h1>
          <div className="prose prose-invert text-muted-foreground space-y-4 text-[15px] leading-relaxed">
            <p>
              AstroGen explores the application of modern generative artificial intelligence
              in astronomy. The system combines multiple deep learning architectures trained
              specifically on space imagery from NASA APOD archives and curated astronomical
              datasets.
            </p>
            <p>
              Unlike general-purpose image generators, every component — from prompt
              conditioning to loss functions — is designed around the structural and
              statistical properties of celestial imagery. The result is a platform you can
              actually trust for research and exploration.
            </p>
            <p>
              The application runs locally on consumer hardware. Generation, captioning, and
              chat all happen on the user's own machine, with the desktop platform providing
              an integrated AI workspace for the full research workflow.
            </p>
          </div>
          <div className="mt-8 flex gap-3">
            <Link
              to="/chat"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-[13px] font-medium hover:opacity-90 transition glow-cyan"
            >
              Begin Session
              <ArrowRight className="size-4" />
            </Link>
            <Link
              to="/"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-border-strong text-[13px] font-medium hover:bg-secondary/40 transition"
            >
              Back to Home
            </Link>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}

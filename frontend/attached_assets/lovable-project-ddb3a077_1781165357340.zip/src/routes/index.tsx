import { createFileRoute } from "@tanstack/react-router";
import Hero from "@/components/astro/home/Hero";
import Architecture from "@/components/astro/home/Architecture";
import Research from "@/components/astro/home/Research";
import Stats from "@/components/astro/home/Stats";
import Categories from "@/components/astro/home/Categories";
import WhyAstroGen from "@/components/astro/home/WhyAstroGen";
import Footer from "@/components/astro/home/Footer";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main>
      <Hero />
      <Stats />
      <Architecture />
      <Research />
      <Categories />
      <WhyAstroGen />
      <Footer />
    </main>
  );
}

import { useEffect } from "react";
import { X, Download, Copy } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

export default function ImagePreview({
  url,
  prompt,
  onClose,
}: {
  url: string | null;
  prompt?: string;
  onClose: () => void;
}) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [onClose]);

  return (
    <AnimatePresence>
      {url && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[120] bg-background/90 backdrop-blur-lg flex flex-col items-center justify-center p-6"
          onClick={onClose}
        >
          <motion.img
            initial={{ scale: 0.96, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.96, opacity: 0 }}
            src={url}
            alt={prompt || "Cosmic preview"}
            className="max-w-[88vw] max-h-[78vh] object-contain rounded-xl border border-border-strong shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          />
          <div
            className="mt-4 flex flex-wrap items-center justify-center gap-2 max-w-[800px]"
            onClick={(e) => e.stopPropagation()}
          >
            {prompt && (
              <p className="w-full text-center text-[13px] text-muted-foreground font-mono px-4">
                {prompt}
              </p>
            )}
            <a
              href={url}
              download={`astrogen-${Date.now()}.png`}
              onClick={() => toast.success("Image downloading…")}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md glass-strong text-[12px] font-medium hover:text-primary transition"
            >
              <Download className="size-3.5" /> Download
            </a>
            {prompt && (
              <button
                onClick={() => {
                  navigator.clipboard.writeText(prompt);
                  toast.success("Prompt copied");
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md glass-strong text-[12px] font-medium hover:text-primary transition"
              >
                <Copy className="size-3.5" /> Copy Prompt
              </button>
            )}
            <button
              onClick={onClose}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md glass-strong text-[12px] font-medium hover:text-destructive transition"
            >
              <X className="size-3.5" /> Close
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

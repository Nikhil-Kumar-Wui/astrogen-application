export default function Logo({ size = 28 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="ag-grad" x1="0" y1="0" x2="40" y2="40">
          <stop offset="0%" stopColor="oklch(0.78 0.16 210)" />
          <stop offset="100%" stopColor="oklch(0.6 0.22 295)" />
        </linearGradient>
      </defs>
      <circle cx="20" cy="20" r="6" fill="url(#ag-grad)" />
      <ellipse
        cx="20"
        cy="20"
        rx="17"
        ry="6"
        stroke="url(#ag-grad)"
        strokeWidth="1.5"
        transform="rotate(-28 20 20)"
        opacity="0.9"
      />
      <ellipse
        cx="20"
        cy="20"
        rx="17"
        ry="6"
        stroke="oklch(0.78 0.16 210 / 0.4)"
        strokeWidth="1"
        transform="rotate(28 20 20)"
      />
      <circle cx="36" cy="9" r="1.4" fill="oklch(0.96 0.01 250)" />
      <circle cx="5" cy="32" r="1" fill="oklch(0.78 0.16 210)" />
    </svg>
  );
}

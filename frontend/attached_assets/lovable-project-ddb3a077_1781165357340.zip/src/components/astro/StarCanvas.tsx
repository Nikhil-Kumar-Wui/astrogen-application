import { useEffect, useState, type CSSProperties } from "react";

type Star = { id: number; bright: boolean; style: CSSProperties };

export default function StarCanvas({ density = 140 }: { density?: number }) {
  const [stars, setStars] = useState<Star[]>([]);

  useEffect(() => {
    const arr: Star[] = [];
    for (let i = 0; i < density; i++) {
      const bright = Math.random() > 0.86;
      const size = bright ? Math.random() * 2 + 2 : Math.random() * 1.4 + 0.6;
      const dur = Math.random() * 4 + 3;
      const del = Math.random() * 6;
      const lo = Math.random() * 0.2;
      const hi = Math.random() * 0.6 + 0.4;
      const r = Math.random();
      const col =
        r > 0.85 ? "#a2d2ff" : r > 0.7 ? "#ffccd5" : r > 0.45 ? "#ffffff" : "#d3cbfb";
      arr.push({
        id: i,
        bright,
        style: {
          left: `${Math.random() * 100}%`,
          top: `${Math.random() * 100}%`,
          ["--sz" as any]: `${size}px`,
          ["--dur" as any]: `${dur}s`,
          ["--del" as any]: `${del}s`,
          ["--lo" as any]: lo,
          ["--hi" as any]: hi,
          ["--col" as any]: col,
          ["--cross" as any]: bright ? `${Math.floor(Math.random() * 6) + 10}px` : undefined,
        } as CSSProperties,
      });
    }
    setStars(arr);
  }, [density]);

  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden -z-10">
      <div className="absolute inset-0 bg-deep" />
      <div className="absolute inset-0 bg-nebula opacity-70" />
      <div className="absolute inset-0 grid-faint opacity-30" />
      {stars.map((s) => (
        <div key={s.id} className={`star ${s.bright ? "bright" : ""}`} style={s.style} />
      ))}
      <div className="shooting-star" style={{ top: "12%", left: "-10%", animationDelay: "2s" }} />
      <div className="shooting-star" style={{ top: "40%", left: "-10%", animationDelay: "9s" }} />
    </div>
  );
}

export default function SectionTitle({
  eyebrow,
  title,
  subtitle,
  align = "left",
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  align?: "left" | "center";
}) {
  return (
    <div className={`mb-12 ${align === "center" ? "text-center mx-auto max-w-2xl" : "max-w-3xl"}`}>
      {eyebrow && (
        <div
          className={`inline-flex items-center gap-2 px-2.5 py-1 rounded-full border border-border bg-secondary/50 text-[10.5px] font-mono uppercase tracking-[0.18em] text-muted-foreground mb-4 ${
            align === "center" ? "" : ""
          }`}
        >
          <span className="size-1 rounded-full bg-primary" />
          {eyebrow}
        </div>
      )}
      <h2 className="font-display text-3xl md:text-4xl font-semibold tracking-tight text-foreground">
        {title}
      </h2>
      {subtitle && (
        <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">{subtitle}</p>
      )}
    </div>
  );
}

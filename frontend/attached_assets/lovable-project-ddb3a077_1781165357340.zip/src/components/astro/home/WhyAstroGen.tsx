import { Check } from "lucide-react";
import { motion } from "framer-motion";
import SectionTitle from "../SectionTitle";

const POINTS = [
  "Trained exclusively on astronomical imagery, not generic photo datasets.",
  "Research-driven architecture with documented contributions.",
  "Multiple generative approaches (diffusion + VAE-GAN) under one roof.",
  "Integrated image understanding via BLIP-2 captioning.",
  "Local desktop deployment — no cloud dependencies for inference.",
  "Scientific evaluation pipeline with quantitative benchmarks.",
];

export default function WhyAstroGen() {
  return (
    <section className="px-6 py-24">
      <div className="mx-auto max-w-[1200px] grid md:grid-cols-2 gap-12 items-center">
        <div>
          <SectionTitle eyebrow="Differentiation" title="Why AstroGen?" />
          <ul className="space-y-3">
            {POINTS.map((p, i) => (
              <motion.li
                key={p}
                initial={{ opacity: 0, x: -10 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: i * 0.05 }}
                className="flex items-start gap-3"
              >
                <span className="mt-0.5 size-5 shrink-0 rounded-full bg-primary/10 border border-primary/40 flex items-center justify-center text-primary">
                  <Check className="size-3" />
                </span>
                <span className="text-[14px] text-muted-foreground leading-relaxed">
                  {p}
                </span>
              </motion.li>
            ))}
          </ul>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="relative aspect-square glass-strong rounded-2xl p-8 overflow-hidden"
        >
          <div className="absolute inset-0 bg-nebula opacity-60" />
          <div className="absolute inset-0 grid-faint opacity-30" />
          <div className="relative h-full flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                System Telemetry
              </span>
              <span className="font-mono text-[10px] text-primary">LIVE</span>
            </div>

            <div className="space-y-3">
              {[
                { l: "Diffusion Loss", v: 0.182, c: "primary" },
                { l: "VAE Reconstruction", v: 0.94, c: "accent" },
                { l: "CLIP Alignment", v: 0.78, c: "primary" },
                { l: "FID (lower = better)", v: 0.42, c: "accent" },
              ].map((m) => (
                <div key={m.l}>
                  <div className="flex justify-between text-[11px] font-mono mb-1">
                    <span className="text-muted-foreground">{m.l}</span>
                    <span className="text-foreground">{m.v.toFixed(2)}</span>
                  </div>
                  <div className="h-1 rounded-full bg-secondary/60 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${m.v * 100}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1.2, ease: "easeOut" }}
                      className={`h-full ${m.c === "primary" ? "bg-primary" : "bg-accent"}`}
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-3 gap-2 text-center">
              {[
                { l: "Models", v: "3" },
                { l: "Classes", v: "9" },
                { l: "Eval", v: "5" },
              ].map((s) => (
                <div key={s.l} className="rounded-lg border border-border bg-surface/40 py-2">
                  <div className="font-display text-xl font-semibold">{s.v}</div>
                  <div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
                    {s.l}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

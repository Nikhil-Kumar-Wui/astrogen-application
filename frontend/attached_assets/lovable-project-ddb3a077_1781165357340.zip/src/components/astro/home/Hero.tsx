import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowRight, GitBranch, Sparkles } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative pt-32 pb-20 px-6">
      <div className="mx-auto max-w-[1200px] text-center relative">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-primary/30 bg-primary/5 text-[11px] font-mono uppercase tracking-[0.2em] text-primary mb-8"
        >
          <span className="size-1.5 rounded-full bg-primary pulse-glow" />
          Astronomical Generative Intelligence Platform
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="font-display text-[68px] md:text-[96px] leading-[0.95] font-semibold tracking-[-0.04em] whitespace-nowrap"
        >
          ASTRO<span className="text-gradient">GEN</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.25 }}
          className="mt-6 text-[17px] md:text-[19px] leading-relaxed text-muted-foreground max-w-2xl mx-auto"
        >
          A research-driven platform for astronomical image generation, analysis, and
          interpretation. Multiple deep-learning architectures trained on NASA APOD archives
          and curated celestial datasets.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-3"
        >
          <Link
            to="/chat"
            className="group inline-flex items-center gap-2 px-5 py-3 rounded-lg bg-primary text-primary-foreground text-[14px] font-medium hover:opacity-90 transition glow-cyan"
          >
            <Sparkles className="size-4" />
            Begin Session
            <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
          </Link>
          <a
            href="#architecture"
            className="inline-flex items-center gap-2 px-5 py-3 rounded-lg border border-border-strong bg-secondary/30 text-[14px] font-medium hover:bg-secondary/60 transition"
          >
            <GitBranch className="size-4" />
            Explore Architecture
          </a>
        </motion.div>

        {/* Floating orbit visualization */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="mt-20 relative h-[280px] flex items-center justify-center"
        >
          <div className="absolute inset-0 bg-nebula opacity-60 blur-3xl" />
          <div className="relative size-[260px]">
            <div className="absolute inset-0 rounded-full border border-border" />
            <div className="absolute inset-6 rounded-full border border-border/60" />
            <div className="absolute inset-12 rounded-full border border-border/40" />
            <div
              className="absolute inset-0 animate-spin"
              style={{ animationDuration: "18s" }}
            >
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 size-3 rounded-full bg-primary glow-cyan" />
            </div>
            <div
              className="absolute inset-6 animate-spin"
              style={{ animationDuration: "12s", animationDirection: "reverse" }}
            >
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 size-2 rounded-full bg-accent glow-nebula" />
            </div>
            <div
              className="absolute inset-12 animate-spin"
              style={{ animationDuration: "8s" }}
            >
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 size-1.5 rounded-full bg-starlight" />
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="size-16 rounded-full bg-gradient-to-br from-primary via-accent to-primary glow-cyan flex items-center justify-center font-display text-xs font-bold tracking-wider">
                AGI
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

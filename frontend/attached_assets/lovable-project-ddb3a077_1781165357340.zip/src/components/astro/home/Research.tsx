import { Brain, Layers3, Waves } from "lucide-react";
import { motion } from "framer-motion";
import SectionTitle from "../SectionTitle";

const ITEMS = [
  {
    icon: Brain,
    title: "Semantic Prompt Conditioning",
    desc: "Astronomy-aware prompt enrichment injects domain knowledge into the generation pipeline, improving fidelity of celestial structures.",
    tokens: ["Knowledge Injection", "Domain Vocab", "Prompt Rewriting"],
  },
  {
    icon: Layers3,
    title: "Multi-Resolution Consistency",
    desc: "Generation consistency enforced across multiple spatial scales, preserving fine stellar detail alongside large-scale structure.",
    tokens: ["Hierarchical", "Multi-Scale", "Structural"],
  },
  {
    icon: Waves,
    title: "Perceptual Astronomy Loss",
    desc: "Custom loss combining VGG features, Sobel edges, frequency-domain analysis, SSIM, and LPIPS for astronomical realism.",
    tokens: ["VGG", "Sobel", "FFT", "SSIM", "LPIPS"],
  },
];

export default function Research() {
  return (
    <section className="px-6 py-24">
      <div className="mx-auto max-w-[1200px]">
        <SectionTitle
          eyebrow="Research Innovations"
          title="Three contributions, one cohesive system"
          subtitle="Original work designed for the unique characteristics of astronomical imagery."
        />

        <div className="grid md:grid-cols-3 gap-4">
          {ITEMS.map((it, i) => {
            const Icon = it.icon;
            return (
              <motion.div
                key={it.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="group relative glass rounded-2xl p-6 hover:-translate-y-1 hover:border-primary/40 transition-all overflow-hidden"
              >
                <div className="absolute -top-20 -right-20 size-40 rounded-full bg-primary/10 blur-3xl opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="relative">
                  <div className="size-11 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 border border-primary/30 flex items-center justify-center text-primary mb-4">
                    <Icon className="size-5" />
                  </div>
                  <h3 className="font-display text-[17px] font-semibold mb-2">{it.title}</h3>
                  <p className="text-[13px] leading-relaxed text-muted-foreground mb-4">
                    {it.desc}
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {it.tokens.map((t) => (
                      <span
                        key={t}
                        className="px-2 py-0.5 rounded font-mono text-[10px] border border-border bg-secondary/40 text-muted-foreground"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

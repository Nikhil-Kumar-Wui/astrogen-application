import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";

const STATS = [
  { value: 6984, suffix: "+", label: "Training Images" },
  { value: 9, suffix: "", label: "Astronomy Classes" },
  { value: 3, suffix: "", label: "Deep Learning Models" },
  { value: 10000, suffix: "+", label: "Generated Samples" },
  { value: 5, suffix: "", label: "Research Modules" },
  { value: 1, suffix: "", label: "Desktop Platform" },
];

function CountUp({ to, suffix }: { to: number; suffix: string }) {
  const [n, setN] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          const dur = 1400;
          const start = performance.now();
          const step = (t: number) => {
            const p = Math.min(1, (t - start) / dur);
            const eased = 1 - Math.pow(1 - p, 3);
            setN(Math.floor(eased * to));
            if (p < 1) requestAnimationFrame(step);
            else setN(to);
          };
          requestAnimationFrame(step);
        }
      },
      { threshold: 0.4 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [to]);

  return (
    <span ref={ref} className="font-display tabular-nums">
      {n.toLocaleString()}
      {suffix}
    </span>
  );
}

export default function Stats() {
  return (
    <section className="px-6 py-20">
      <div className="mx-auto max-w-[1200px]">
        <div className="glass-strong rounded-2xl p-8 md:p-10 relative overflow-hidden">
          <div className="absolute inset-0 grid-faint opacity-40 pointer-events-none" />
          <div className="absolute -top-32 -right-32 size-80 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-32 -left-32 size-80 bg-accent/10 rounded-full blur-3xl" />

          <div className="relative grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {STATS.map((s, i) => (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.06 }}
                className="text-center md:text-left"
              >
                <div className="text-3xl md:text-4xl font-semibold tracking-tight text-foreground">
                  <CountUp to={s.value} suffix={s.suffix} />
                </div>
                <div className="mt-2 text-[11px] font-mono uppercase tracking-[0.16em] text-muted-foreground">
                  {s.label}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

import Logo from "../Logo";

export default function Footer() {
  return (
    <footer className="px-6 py-12 border-t border-border/50 mt-12">
      <div className="mx-auto max-w-[1200px] grid md:grid-cols-3 gap-8 items-start">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Logo size={24} />
            <span className="font-display text-base font-semibold tracking-tight">
              ASTRO<span className="text-gradient">GEN</span>
            </span>
          </div>
          <p className="text-[12.5px] text-muted-foreground leading-relaxed max-w-xs">
            Astronomical Generative Intelligence Platform. A research-focused AI system for
            astronomical image generation and analysis.
          </p>
        </div>

        <div>
          <div className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-3">
            System
          </div>
          <ul className="space-y-1.5 text-[13px]">
            <li className="flex justify-between"><span className="text-muted-foreground">Version</span><span className="font-mono">v1.0.0</span></li>
            <li className="flex justify-between"><span className="text-muted-foreground">Models</span><span className="font-mono text-emerald-400">Ready</span></li>
            <li className="flex justify-between"><span className="text-muted-foreground">Dataset</span><span className="font-mono text-emerald-400">Loaded</span></li>
            <li className="flex justify-between"><span className="text-muted-foreground">Runtime</span><span className="font-mono">Local</span></li>
          </ul>
        </div>

        <div>
          <div className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-3">
            Research Stack
          </div>
          <ul className="space-y-1.5 text-[13px] text-muted-foreground">
            <li>LoRA · Stable Diffusion</li>
            <li>VAE-GAN with Perceptual Loss</li>
            <li>BLIP-2 Vision Language</li>
            <li>NASA APOD Dataset</li>
          </ul>
        </div>
      </div>
      <div className="mx-auto max-w-[1200px] mt-10 pt-6 border-t border-border/40 flex flex-col md:flex-row justify-between gap-3 text-[11px] text-muted-foreground font-mono">
        <span>© {new Date().getFullYear()} AstroGen Research</span>
        <span>Mission Control · Online</span>
      </div>
    </footer>
  );
}

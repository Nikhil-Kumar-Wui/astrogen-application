import { Database, Layers, Cpu, Eye, BarChart3, Monitor } from "lucide-react";
import { motion } from "framer-motion";
import SectionTitle from "../SectionTitle";

const STAGES = [
  {
    icon: Database,
    name: "Dataset Collection",
    desc: "Curated astronomical imagery from NASA APOD archives, normalized and class-balanced for domain-specific training.",
    tag: "6,984+ images",
  },
  {
    icon: Layers,
    name: "LoRA Stable Diffusion",
    desc: "Fine-tuned latent diffusion with low-rank adaptation specialized for astronomical scene generation.",
    tag: "Text → Image",
  },
  {
    icon: Cpu,
    name: "VAE-GAN Architecture",
    desc: "Custom generative model trained with a Perceptual Astronomy Loss for improved structural realism.",
    tag: "Latent Sampling",
  },
  {
    icon: Eye,
    name: "BLIP-2 Captioning",
    desc: "Vision-language model for understanding and describing celestial objects in uploaded imagery.",
    tag: "Image → Caption",
  },
  {
    icon: BarChart3,
    name: "Evaluation Framework",
    desc: "Quantitative assessment via CLIP Score, FID, Inception Score, BLEU, and comparative visual studies.",
    tag: "Benchmarks",
  },
  {
    icon: Monitor,
    name: "Desktop Platform",
    desc: "Integrated AI workspace for generation, analysis, and interaction running entirely on local hardware.",
    tag: "This App",
  },
];

export default function Architecture() {
  return (
    <section id="architecture" className="px-6 py-24 relative">
      <div className="mx-auto max-w-[1200px]">
        <SectionTitle
          eyebrow="Research Architecture"
          title="From raw imagery to interactive intelligence"
          subtitle="A six-stage pipeline pairing classical astronomical data curation with modern generative learning."
        />

        <div className="relative">
          {/* Connecting line */}
          <div className="absolute left-6 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-border-strong to-transparent md:left-1/2 md:-translate-x-1/2" />

          <div className="space-y-4">
            {STAGES.map((s, i) => {
              const Icon = s.icon;
              const isLeft = i % 2 === 0;
              return (
                <motion.div
                  key={s.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-80px" }}
                  transition={{ duration: 0.5, delay: i * 0.05 }}
                  className={`relative flex gap-4 md:gap-12 items-stretch ${
                    isLeft ? "md:flex-row" : "md:flex-row-reverse"
                  }`}
                >
                  <div className="hidden md:block flex-1" />
                  <div className="relative z-10 shrink-0 size-12 md:size-14 rounded-full glass-strong border-primary/40 border flex items-center justify-center text-primary glow-cyan">
                    <Icon className="size-5 md:size-6" />
                  </div>
                  <div className="flex-1 glass rounded-xl p-5 hover:border-primary/40 transition group">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                        Stage 0{i + 1}
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-primary/10 text-primary border border-primary/20">
                        {s.tag}
                      </span>
                    </div>
                    <h3 className="font-display text-lg font-semibold mb-1.5">{s.name}</h3>
                    <p className="text-[13.5px] leading-relaxed text-muted-foreground">
                      {s.desc}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

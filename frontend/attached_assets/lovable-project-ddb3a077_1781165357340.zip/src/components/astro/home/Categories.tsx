import { motion } from "framer-motion";
import SectionTitle from "../SectionTitle";

const CATS = [
  { name: "Galaxy", desc: "Spiral and elliptical galactic structures." },
  { name: "Nebula", desc: "Emission, reflection, and planetary nebulae." },
  { name: "Planet", desc: "Solar and exoplanetary bodies." },
  { name: "Moon", desc: "Lunar and planetary satellite surfaces." },
  { name: "Star", desc: "Stellar lifecycles and classes." },
  { name: "Sun", desc: "Solar dynamics, flares, and coronae." },
  { name: "Comet", desc: "Cometary nuclei and dust tails." },
  { name: "Aurora", desc: "Magnetospheric atmospheric phenomena." },
  { name: "Deep-Space", desc: "Distant clusters and cosmic web." },
];

export default function Categories() {
  return (
    <section className="px-6 py-24">
      <div className="mx-auto max-w-[1200px]">
        <SectionTitle
          eyebrow="Coverage"
          title="Nine astronomical categories"
          subtitle="The dataset spans the full range of subjects encountered in modern astrophotography and survey imagery."
        />
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-3">
          {CATS.map((c, i) => (
            <motion.div
              key={c.name}
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.35, delay: i * 0.04 }}
              className="group relative glass rounded-xl p-5 hover:border-primary/40 transition cursor-default overflow-hidden"
            >
              <div className="absolute top-2 right-2 size-2 rounded-full bg-primary/60 group-hover:bg-primary group-hover:shadow-[0_0_8px_currentColor] text-primary transition" />
              <div className="font-display text-base font-semibold">{c.name}</div>
              <div className="mt-1 text-[12px] text-muted-foreground leading-relaxed">
                {c.desc}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

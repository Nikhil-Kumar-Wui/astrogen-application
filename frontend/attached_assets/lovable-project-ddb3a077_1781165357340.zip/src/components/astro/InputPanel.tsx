import { useRef, useState } from "react";
import { Paperclip, Send, X, Sparkles } from "lucide-react";

export type ModelKey = "lora_sd" | "vae_gan" | "blip2" | "gemini";

const MODELS: { value: ModelKey; label: string; hint: string }[] = [
  { value: "lora_sd", label: "LoRA Stable Diffusion", hint: "Text → Image" },
  { value: "vae_gan", label: "VAE-GAN", hint: "Random latent sampling" },
  { value: "blip2", label: "BLIP-2 Vision", hint: "Image captioning" },
  { value: "gemini", label: "Gemini Pro", hint: "Astronomy chat" },
];

export default function InputPanel({
  onSend,
  isLoading,
  initialText = "",
  initialModel = "lora_sd",
}: {
  onSend: (p: { text: string; model: ModelKey; imageB64: string | null }) => void;
  isLoading: boolean;
  initialText?: string;
  initialModel?: ModelKey;
}) {
  const [text, setText] = useState(initialText);
  const [model, setModel] = useState<ModelKey>(initialModel);
  const [imageB64, setImageB64] = useState<string | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const r = new FileReader();
    r.onloadend = () => {
      const result = r.result as string;
      setImagePreview(result);
      setImageB64(result.split(",")[1]);
    };
    r.readAsDataURL(f);
  };

  const clearImage = () => {
    setImagePreview(null);
    setImageB64(null);
    if (fileRef.current) fileRef.current.value = "";
  };

  const send = () => {
    const t = text.trim();
    if (!t && !imageB64 && model !== "vae_gan") return;
    onSend({ text: t, model, imageB64 });
    setText("");
    clearImage();
  };

  const onKey = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      send();
    }
  };

  const placeholder =
    model === "vae_gan"
      ? "Press Send to sample a random deep-space image…"
      : model === "blip2"
      ? "Upload an image, then optionally ask a question…"
      : model === "gemini"
      ? "Ask about black holes, nebulae, missions, physics…"
      : "Describe a galaxy, nebula, or cosmic scene…";

  return (
    <div className="glass-strong rounded-2xl p-3 border border-border/70">
      <div className="flex items-center gap-2 mb-2 px-1">
        <Sparkles className="size-3.5 text-primary" />
        <select
          className="bg-transparent text-[12.5px] font-medium focus:outline-none cursor-pointer hover:text-primary transition"
          value={model}
          onChange={(e) => setModel(e.target.value as ModelKey)}
          disabled={isLoading}
        >
          {MODELS.map((m) => (
            <option key={m.value} value={m.value} className="bg-popover text-foreground">
              {m.label} — {m.hint}
            </option>
          ))}
        </select>
        <div className="flex-1" />
        <input
          type="file"
          ref={fileRef}
          className="hidden"
          accept="image/*"
          onChange={handleFile}
        />
        <button
          onClick={() => fileRef.current?.click()}
          disabled={isLoading}
          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-[11.5px] font-medium border border-border bg-secondary/40 hover:bg-secondary transition disabled:opacity-50"
        >
          <Paperclip className="size-3.5" />
          Attach
        </button>
      </div>

      {imagePreview && (
        <div className="flex items-center gap-3 mb-2 p-2 rounded-lg border border-border bg-surface/50">
          <img src={imagePreview} alt="" className="size-12 object-cover rounded" />
          <span className="text-[12px] text-muted-foreground flex-1">
            Image attached · Ready for analysis
          </span>
          <button
            onClick={clearImage}
            className="size-7 rounded flex items-center justify-center hover:bg-destructive/10 hover:text-destructive transition"
            aria-label="Remove image"
          >
            <X className="size-4" />
          </button>
        </div>
      )}

      <div className="flex gap-2 items-end">
        <textarea
          rows={2}
          className="flex-1 resize-none bg-transparent px-3 py-2 text-[14px] focus:outline-none placeholder:text-muted-foreground/70"
          placeholder={placeholder}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={onKey}
          disabled={isLoading}
        />
        <button
          onClick={send}
          disabled={isLoading || (!text.trim() && !imageB64 && model !== "vae_gan")}
          className="shrink-0 h-10 px-4 rounded-lg bg-primary text-primary-foreground text-[13px] font-medium hover:opacity-90 transition glow-cyan disabled:opacity-40 disabled:cursor-not-allowed disabled:shadow-none inline-flex items-center gap-1.5"
        >
          <Send className="size-3.5" />
          Send
        </button>
      </div>

      <div className="px-1 mt-1.5 text-[11px] text-muted-foreground/70 font-mono">
        Ctrl+Enter to send · Attach an image to caption or analyze
      </div>
    </div>
  );
}

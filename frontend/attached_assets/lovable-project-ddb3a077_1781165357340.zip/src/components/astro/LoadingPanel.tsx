import { useEffect, useState } from "react";

const MESSAGES = [
  "Initializing AI model...",
  "Preparing prompt embeddings...",
  "Scanning the cosmos...",
  "Mapping star systems...",
  "Analyzing celestial patterns...",
  "Generating cosmic scene...",
  "Rendering deep-space imagery...",
  "Finalizing output...",
];

export default function LoadingPanel({
  active,
  label,
}: {
  active: boolean;
  label?: string;
}) {
  const [progress, setProgress] = useState(0);
  const [phaseIdx, setPhaseIdx] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const estimate = 18;

  useEffect(() => {
    if (!active) {
      setProgress(0);
      setPhaseIdx(0);
      setElapsed(0);
      return;
    }
    const start = Date.now();
    const tick = setInterval(() => {
      const e = (Date.now() - start) / 1000;
      setElapsed(e);
      // Asymptotic progress: approaches 95% but never completes until `active` flips off
      const pct = Math.min(95, (1 - Math.exp(-e / 6)) * 100);
      setProgress(pct);
      setPhaseIdx(Math.min(MESSAGES.length - 1, Math.floor(e / 2.2)));
    }, 120);
    return () => clearInterval(tick);
  }, [active]);

  if (!active) return null;
  const remaining = Math.max(1, Math.ceil(estimate - elapsed));

  return (
    <div className="glass rounded-2xl p-6 my-4 overflow-hidden relative">
      <div className="absolute inset-0 bg-nebula opacity-50 pointer-events-none" />
      <div className="relative flex items-center gap-5">
        {/* Orbiting visualization */}
        <div className="relative size-20 shrink-0">
          <div className="absolute inset-0 rounded-full border border-primary/30" />
          <div className="absolute inset-2 rounded-full border border-accent/30" />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="size-3.5 rounded-full bg-gradient-to-br from-primary to-accent glow-cyan" />
          </div>
          <div
            className="absolute inset-0 animate-spin"
            style={{ animationDuration: "3s" }}
          >
            <div className="size-1.5 rounded-full bg-primary absolute top-0 left-1/2 -translate-x-1/2 shadow-[0_0_8px_currentColor] text-primary" />
          </div>
          <div
            className="absolute inset-0 animate-spin"
            style={{ animationDuration: "5s", animationDirection: "reverse" }}
          >
            <div className="size-1 rounded-full bg-accent absolute bottom-0 left-1/2 -translate-x-1/2 shadow-[0_0_8px_currentColor] text-accent" />
          </div>
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-baseline justify-between gap-3 mb-2">
            <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-primary">
              Mission Control
            </span>
            <span className="font-mono text-[11px] text-muted-foreground">
              ~{remaining}s · {Math.round(progress)}%
            </span>
          </div>
          <div className="text-sm font-medium text-foreground mb-3 truncate">
            {label || MESSAGES[phaseIdx]}
          </div>
          <div className="h-1.5 rounded-full bg-secondary/60 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-primary via-primary to-accent transition-[width] duration-500 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

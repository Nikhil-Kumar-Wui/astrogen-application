import { Copy, Download, Maximize2, Repeat, User, Bot } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { imageUrl, type Message } from "@/lib/api";

const MODEL_LABEL: Record<string, string> = {
  lora_sd: "LoRA · Stable Diffusion",
  vae_gan: "VAE-GAN",
  gemini: "Gemini Pro",
  blip2: "BLIP-2 Vision",
};

export default function MessageBubble({
  message,
  onPreview,
  onRegenerate,
}: {
  message: Message;
  onPreview: (url: string, prompt?: string) => void;
  onRegenerate?: (msg: Message) => void;
}) {
  const isUser = message.role === "user";
  const time = message.timestamp
    ? new Date(message.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    : "";

  const copy = (text: string, label = "Copied to clipboard") => {
    navigator.clipboard.writeText(text || "");
    toast.success(label);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className={`flex gap-3 ${isUser ? "flex-row-reverse" : ""}`}
    >
      <div
        className={`size-8 shrink-0 rounded-full flex items-center justify-center border ${
          isUser
            ? "bg-primary/10 border-primary/40 text-primary"
            : "bg-accent/10 border-accent/40 text-accent"
        }`}
      >
        {isUser ? <User className="size-4" /> : <Bot className="size-4" />}
      </div>

      <div className={`flex-1 min-w-0 max-w-[78%] ${isUser ? "items-end" : ""}`}>
        <div
          className={`flex items-center gap-2 mb-1 text-[11px] text-muted-foreground ${
            isUser ? "justify-end" : ""
          }`}
        >
          <span className="font-medium text-foreground/80">
            {isUser ? "You" : "AstroGen"}
          </span>
          {message.model_used && (
            <span className="px-1.5 py-0.5 rounded font-mono text-[10px] bg-secondary/60 border border-border/60">
              {MODEL_LABEL[message.model_used] || message.model_used}
            </span>
          )}
          {time && <span className="font-mono text-[10px]">{time}</span>}
        </div>

        {message.msg_type === "image" ? (
          <div className="rounded-xl overflow-hidden glass border border-border/60">
            <div className="relative group bg-black/30">
              <motion.img
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                src={imageUrl(message.content) || ""}
                alt={message.prompt || "Generated astronomical image"}
                className="w-full max-h-[520px] object-contain cursor-zoom-in"
                onClick={() =>
                  onPreview(imageUrl(message.content) || "", message.prompt)
                }
              />
              <button
                onClick={() => onPreview(imageUrl(message.content) || "", message.prompt)}
                className="absolute top-2 right-2 size-8 rounded-md glass-strong flex items-center justify-center opacity-0 group-hover:opacity-100 transition hover:bg-primary hover:text-primary-foreground"
                aria-label="Full screen"
              >
                <Maximize2 className="size-4" />
              </button>
            </div>
            {message.prompt && (
              <div className="px-3 py-2 text-[12px] text-muted-foreground border-t border-border/40 font-mono">
                {message.prompt}
              </div>
            )}
            <div className="flex flex-wrap gap-1.5 p-2 border-t border-border/40 bg-surface-2/40">
              <BtnAction
                onClick={() => copy(message.prompt || "", "Prompt copied")}
                icon={Copy}
                label="Copy Prompt"
              />
              <a
                href={imageUrl(message.content) || "#"}
                download={`astrogen-${Date.now()}.png`}
                target="_blank"
                rel="noreferrer"
                onClick={() => toast.success("Image downloading…")}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-[11.5px] font-medium border border-border bg-secondary/40 hover:bg-secondary transition"
              >
                <Download className="size-3.5" />
                Download
              </a>
              {onRegenerate && (
                <BtnAction
                  onClick={() => onRegenerate(message)}
                  icon={Repeat}
                  label="Generate Similar"
                />
              )}
            </div>
          </div>
        ) : (
          <div
            className={`rounded-2xl px-4 py-3 text-[14px] leading-relaxed whitespace-pre-wrap break-words ${
              isUser
                ? "bg-primary text-primary-foreground rounded-tr-sm"
                : "glass border border-border/60 assistant-prose rounded-tl-sm"
            }`}
          >
            {message.content}
          </div>
        )}

        {!isUser && message.msg_type !== "image" && (
          <div className="mt-1.5 flex gap-1.5">
            <BtnAction
              onClick={() => copy(message.content, "Response copied")}
              icon={Copy}
              label="Copy"
            />
            {onRegenerate && (
              <BtnAction
                onClick={() => onRegenerate(message)}
                icon={Repeat}
                label="Retry"
              />
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
}

function BtnAction({
  onClick,
  icon: Icon,
  label,
}: {
  onClick: () => void;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-[11.5px] font-medium border border-border bg-secondary/40 hover:bg-secondary hover:border-primary/40 transition"
    >
      <Icon className="size-3.5" />
      {label}
    </button>
  );
}

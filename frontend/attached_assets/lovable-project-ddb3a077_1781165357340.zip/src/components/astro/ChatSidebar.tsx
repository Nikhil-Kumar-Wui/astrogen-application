import { Plus, History, Image as ImageIcon, Trash2, Telescope } from "lucide-react";
import type { Session } from "@/lib/api";

export default function ChatSidebar({
  sessions,
  activeId,
  onSelect,
  onCreate,
  onDelete,
  onOpenGallery,
}: {
  sessions: Session[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onCreate: () => void;
  onDelete: (id: string) => void;
  onOpenGallery: () => void;
}) {
  return (
    <aside className="w-72 shrink-0 glass border-r border-border/60 flex flex-col h-full">
      <div className="px-4 py-4 border-b border-border/50">
        <button
          onClick={onCreate}
          className="w-full flex items-center justify-center gap-2 h-10 rounded-lg bg-primary text-primary-foreground text-[13px] font-medium hover:opacity-90 transition glow-cyan"
        >
          <Plus className="size-4" />
          New Session
        </button>
      </div>

      <div className="px-4 pt-4 pb-2 flex items-center gap-2 text-[10.5px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
        <History className="size-3" />
        Mission Log
      </div>

      <div className="flex-1 overflow-y-auto px-2 pb-2">
        {sessions.length === 0 && (
          <div className="px-3 py-6 text-center text-[12px] text-muted-foreground">
            <Telescope className="size-5 mx-auto mb-2 opacity-50" />
            No sessions yet
          </div>
        )}
        {sessions.map((s) => {
          const active = s.id === activeId;
          return (
            <div
              key={s.id}
              onClick={() => onSelect(s.id)}
              className={`group flex items-center gap-2 px-3 py-2 my-0.5 rounded-md cursor-pointer transition ${
                active
                  ? "bg-secondary/80 text-foreground"
                  : "text-muted-foreground hover:bg-secondary/40 hover:text-foreground"
              }`}
            >
              <span
                className={`size-1.5 rounded-full shrink-0 ${
                  active ? "bg-primary shadow-[0_0_6px_currentColor] text-primary" : "bg-border-strong"
                }`}
              />
              <span className="flex-1 truncate text-[13px]" title={s.title}>
                {s.title}
              </span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(s.id);
                }}
                className="opacity-0 group-hover:opacity-100 transition text-muted-foreground hover:text-destructive"
                aria-label="Delete session"
              >
                <Trash2 className="size-3.5" />
              </button>
            </div>
          );
        })}
      </div>

      <div className="p-4 border-t border-border/50">
        <button
          onClick={onOpenGallery}
          className="w-full flex items-center justify-center gap-2 h-9 rounded-lg border border-border bg-secondary/40 text-[12.5px] font-medium hover:bg-secondary transition"
        >
          <ImageIcon className="size-4" />
          Gallery
        </button>
      </div>
    </aside>
  );
}

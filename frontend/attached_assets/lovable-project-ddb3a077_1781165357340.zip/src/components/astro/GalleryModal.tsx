import { useEffect, useState } from "react";
import { X, Download } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { api, imageUrl, type GalleryItem } from "@/lib/api";

export default function GalleryModal({
  open,
  onClose,
  onPreview,
}: {
  open: boolean;
  onClose: () => void;
  onPreview: (url: string, prompt?: string) => void;
}) {
  const [items, setItems] = useState<GalleryItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!open) return;
    setLoading(true);
    api
      .getGallery(120)
      .then(setItems)
      .catch(() => setItems([]))
      .finally(() => setLoading(false));
  }, [open]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] bg-background/80 backdrop-blur-md flex items-center justify-center p-6"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.96, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.96, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="glass-strong rounded-2xl w-full max-w-6xl max-h-[85vh] flex flex-col border border-border-strong"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-border/60">
              <div>
                <h3 className="font-display text-lg font-semibold">Deep-Space Archive</h3>
                <p className="text-[12px] text-muted-foreground font-mono">
                  {items.length} captures
                </p>
              </div>
              <button
                onClick={onClose}
                className="size-9 rounded-md flex items-center justify-center hover:bg-secondary transition"
                aria-label="Close"
              >
                <X className="size-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6">
              {loading ? (
                <div className="text-center py-20 text-muted-foreground font-mono text-sm">
                  Scanning archive…
                </div>
              ) : items.length === 0 ? (
                <div className="text-center py-20 text-muted-foreground">
                  <p className="font-mono text-sm">No captures yet</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                  {items.map((img, idx) => {
                    const full = imageUrl(img.filepath) || "";
                    const thumb = img.thumbnail_b64
                      ? `data:image/png;base64,${img.thumbnail_b64}`
                      : full;
                    return (
                      <button
                        key={img.id ?? idx}
                        onClick={() => onPreview(full, img.prompt)}
                        className="group relative aspect-square rounded-lg overflow-hidden border border-border/60 hover:border-primary/60 transition"
                      >
                        <img
                          src={thumb}
                          alt={img.prompt || "Capture"}
                          className="w-full h-full object-cover transition-transform group-hover:scale-105"
                          loading="lazy"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-background/95 via-background/30 to-transparent opacity-0 group-hover:opacity-100 transition flex flex-col justify-end p-3 text-left">
                          <div className="text-[10px] font-mono uppercase tracking-wider text-primary mb-1">
                            {img.model || "model"}
                          </div>
                          <div className="text-[11.5px] line-clamp-2 text-foreground">
                            {img.prompt || "Random latent"}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

import { Link, useRouterState } from "@tanstack/react-router";
import { Sparkles, MessageSquare, Image as ImageIcon, Info, Activity } from "lucide-react";
import Logo from "./Logo";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";

const NAV = [
  { to: "/", label: "Home", icon: Sparkles },
  { to: "/chat", label: "Workspace", icon: MessageSquare },
  { to: "/analyze", label: "Analyze", icon: ImageIcon },
  { to: "/about", label: "About", icon: Info },
];

export default function Navbar() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [online, setOnline] = useState(false);

  useEffect(() => {
    let alive = true;
    const ping = async () => {
      try {
        await api.getStatus();
        if (alive) setOnline(true);
      } catch {
        if (alive) setOnline(false);
      }
    };
    ping();
    const id = setInterval(ping, 5000);
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, []);

  return (
    <header className="fixed top-0 inset-x-0 z-50">
      <div className="glass-strong border-b border-border/60">
        <nav className="mx-auto max-w-[1400px] px-6 h-14 flex items-center gap-8">
          <Link
            to="/"
            className="flex items-center gap-2.5 group cursor-pointer"
            aria-label="AstroGen Home"
          >
            <span className="transition-transform group-hover:rotate-12 group-hover:scale-110">
              <Logo size={26} />
            </span>
            <span className="font-display text-[17px] font-semibold tracking-tight whitespace-nowrap">
              ASTRO<span className="text-gradient">GEN</span>
            </span>
          </Link>

          <ul className="flex items-center gap-1">
            {NAV.map(({ to, label, icon: Icon }) => {
              const active = to === "/" ? path === "/" : path.startsWith(to);
              return (
                <li key={to}>
                  <Link
                    to={to}
                    className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-md text-[13px] font-medium transition-all ${
                      active
                        ? "text-foreground bg-secondary/60"
                        : "text-muted-foreground hover:text-foreground hover:bg-secondary/40"
                    }`}
                  >
                    <Icon className="size-3.5" />
                    {label}
                    {active && (
                      <span className="absolute -bottom-px left-3 right-3 h-px bg-gradient-to-r from-transparent via-primary to-transparent" />
                    )}
                  </Link>
                </li>
              );
            })}
          </ul>

          <div className="flex-1" />

          <div className="flex items-center gap-3">
            <div
              className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-[11px] font-mono uppercase tracking-wider border ${
                online
                  ? "border-emerald-500/30 bg-emerald-500/5 text-emerald-300"
                  : "border-destructive/30 bg-destructive/5 text-destructive"
              }`}
              title={online ? "Backend online" : "Backend offline"}
            >
              <span
                className={`size-1.5 rounded-full ${
                  online ? "bg-emerald-400 pulse-glow" : "bg-destructive"
                }`}
              />
              {online ? "Online" : "Offline"}
            </div>
            <Link
              to="/chat"
              className="hidden md:inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md bg-primary text-primary-foreground text-[12.5px] font-medium hover:opacity-90 transition-opacity glow-cyan"
            >
              <Activity className="size-3.5" />
              Begin Session
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
}
